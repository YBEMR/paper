"""Bind the user's current design-and-execute instruction to the frozen finite plan. No science."""
from pathlib import Path
import sys,datetime,json,shutil,psutil
ROOT=Path(__file__).resolve().parent.parent
PACKAGE=ROOT/'work/mechanism_trials_v1'
sys.path.insert(0,str(PACKAGE))
from guard import read,save,sha,verify_plan,verify_approval,environment_snapshot
plan=verify_plan(PACKAGE/'plan.json',ROOT,PACKAGE)
assert not (ROOT/plan['execution_directory']).exists(),'Single-use ledger already exists'
tests=read(ROOT/'work/mechanism_trials_control_test.json')
active=[]
for p in psutil.process_iter(['pid','name','create_time']):
    if (p.info['name'] or '').lower()=='matlab.exe':active.append(p.info)
assert not active,'Active MATLAB process present; do not compete with independent work'
assert environment_snapshot()==plan['environment']
assert Path(plan['matlab']).is_file()
decision='基于提交3baeae8，对正式A/B/C的模型、求解过程、根LP及返回候选进行只读机制分析。重点解释B与C整数变量相同、C原生时间更短但取得根LP及SAFE返回的现象，同时研究为什么C只返回共同初解。交付一个有限可重复性方案和一个以“不同调度且完整SAFE、严格能耗改善”为验收目标的后续实验方案。然后执行这个方案'
approval=dict(read(PACKAGE/'approval.template.json'),approved=True,
    user_decision_reference='Current conversation user instruction: '+decision,
    authorization_interpretation='User authorizes design and execution. Assistant concretized three finite trials before launch; not a claim that user specified each setting.',
    concrete_protocol_sha256=sha(ROOT/'outputs/R1机制复核与有限实验方案.txt'),
    previous_authorizations_reused=False,created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
verify_approval(approval,sha(PACKAGE/'plan.json'))
save(ROOT/'work/mechanism_trials_approval.json',approval)
files=['outputs/R1机制复核与有限实验方案.txt','work/mechanism_readonly.py','work/mechanism_readonly.json',
       'work/mechanism_readonly_notes.txt','work/native_readonly_notes.txt','work/mechanism_trials_control_test.json','work/mechanism_trials_control_test.log']
save(ROOT/'work/mechanism_trials_preexecution.json',dict(plan_sha256=sha(PACKAGE/'plan.json'),
    approval_sha256=sha(ROOT/'work/mechanism_trials_approval.json'),created_utc=approval['created_utc'],
    environment=environment_snapshot(),active_matlab_processes=active,
    free_memory_bytes=psutil.virtual_memory().available,free_disk_bytes=shutil.disk_usage(ROOT).free,
    evidence_sha256={f:sha(ROOT/f) for f in files},source_bindings_verified=len(plan['workspace_files']),
    package_bindings_verified=len(plan['package_files']),scientific_calls_before_launch=0,
    execution_ledger_present=False,maximum_new_native_calls=3,previous_claims_untouched=True))
print(json.dumps({'approved_finite_plan':sha(PACKAGE/'plan.json'),'calls_maximum':3,'active_matlab':active}))
