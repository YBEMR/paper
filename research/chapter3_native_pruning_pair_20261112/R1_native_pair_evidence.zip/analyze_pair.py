"""Read-only audit of saved evidence; no model building or evaluation."""
from pathlib import Path
import hashlib
import json
import math
from decimal import Decimal
import sys

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT/'pair_source'
PAIR = ROOT/'execution/pair'
OUT = ROOT/'analysis'

def read(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def digest(v): return hashlib.sha256(json.dumps(v,sort_keys=True,ensure_ascii=False,separators=(',',':'),default=str).encode()).hexdigest()
def number(v): return isinstance(v,(int,float)) and not isinstance(v,bool) and math.isfinite(v)

def analyze():
    OUT.mkdir(exist_ok=False)
    summary=read(PAIR/'pair_summary.json')
    manifest=read(SOURCE/'bundle_manifest.json')
    checks=[]
    def check(name, passed): checks.append(dict(name=name,passed=bool(passed)))
    for name, expected in manifest['files'].items():
        check('source:'+name, sha(SOURCE/name)==expected)
    check('no_retry',summary['retries']==0)
    check('two_arms', [r['arm'] for r in summary['results']]==['off','on'])
    check('pair_integrity',summary['pair_initialization_and_cleanup_valid'])
    plan=read(ROOT/'execution/plan.json')
    check('plan_identity',sha(ROOT/'execution/plan.json')==read(ROOT/'execution/plan.json.identity.json')['sha256'])
    check('300s_no_post',plan['seconds']==300 and plan['extra_post_budget_evaluation_s']==0)
    metrics=[]
    rows=[]
    for s in summary['results']:
        arm=s['arm'];folder=PAIR/arm
        if not (folder/'method/result.json').exists():
            metrics.append(dict(arm=arm,status=s));continue
        r=read(folder/'method/result.json')
        session=read(folder/'method/matlab/session.json')
        cleanup=read(folder/'method/matlab/closed.json')
        ev=r.get('evaluation') or {}
        initial=r.get('initialisation') or {}
        w=initial.get('witness') or {}
        seed_ev=w.get('evaluation') or {}
        check(arm+':same_source_after',s.get('source_integrity_after'))
        check(arm+':cleanup',s.get('cleanup_complete'))
        check(arm+':guard',s.get('seed_guard',{}).get('status')=='PASSED')
        check(arm+':switches',s['flags']['propagate_support'] and s['flags']['prune_joint_states']==(arm=='on'))
        check(arm+':candidate_digest',digest(r.get('safe_candidate'))==s.get('candidate_sha256'))
        check(arm+':seed_digest',digest(w.get('candidate'))==s.get('seed_guard',{}).get('candidate_sha256'))
        check(arm+':timely_complete_SAFE',ev.get('state')=='SAFE' and ev.get('rankable_energy') and 0<=ev.get('completed_at_elapsed_s',300)<300)
        check(arm+':scene_complete_SAFE',all(v.get('state')=='SAFE' and v.get('complete') for v in ev.get('scenes',{}).values()) and len(ev.get('scenes',{}))==2)
        progress=r.get('diagnostic',{}).get('solver_progress',[])
        callbacks=[e for e in progress if e.get('kind')=='callback']
        root=[e for e in callbacks if e.get('values',{}).get('phase')=='rootlp']
        after=[e for e in callbacks if e.get('values',{}).get('phase') in ('heuristics','cutgen','branching')]
        bounds=[e for e in callbacks if number(e.get('values',{}).get('lowerbound'))]
        for e in callbacks:
            rows.append(dict(arm=arm,**e))
        native=[]
        for f in sorted((folder/'method/matlab').glob('request_*.response.json')):
            raw=read(f)
            native.append(dict(file=str(f.relative_to(ROOT)),sha256=sha(f),status=raw.get('status'),exitflag=raw.get('exitflag'),fval=raw.get('fval'),output=raw.get('output'),options=raw.get('options'),phase_seconds=raw.get('phase_seconds'),request_wall_seconds=raw.get('request_wall_seconds'),x_length=len(raw['x']) if isinstance(raw.get('x'),list) else None,scope='raw file may be late; acceptance determined only by method receipt'))
        diag=r.get('diagnostic') or {}
        evals=diag.get('evaluations',[])
        candidate_identity_rows=[dict(source=e.get('source'),equals_initial=e.get('candidate')==w.get('candidate'),
            canonical_candidate_sha256=digest(e.get('candidate')),accepted_safe=e.get('accepted_safe'),
            energy=(e.get('evaluation') or {}).get('safe_upper_bound_J'),
            evaluation_returned_at_s=e.get('evaluation_returned_at_s')) for e in evals]
        seed_attempts=initial.get('attempts',[])
        t=r['timing'];c=r['construction'];p=t['phases_exclusive_s']
        m=dict(arm=arm,state=r['state'],reason=r.get('reason'),model=r['model_summary'],
            build_s=p.get('model_construction'),matrix_export_s=p.get('matrix_export'),
            startup_s=p.get('solver_startup'),initial_SAFE_s=seed_ev.get('completed_at_elapsed_s'),
            initial_upper_bound_J=seed_ev.get('safe_upper_bound_J'),
            initial_candidate_sha256=digest(w.get('candidate')),final_candidate_sha256=s.get('candidate_sha256'),
            final_upper_bound_J=ev.get('safe_upper_bound_J'),best_SAFE_completed_s=ev.get('completed_at_elapsed_s'),
            equals_initial=s.get('equals_initial'),strict_energy_improvement_certified=r.get('strict_energy_improvement_certified'),
            energy_improvement_percent=float((Decimal(seed_ev['safe_upper_bound_J'])-Decimal(ev['safe_upper_bound_J']))/Decimal(seed_ev['safe_upper_bound_J'])*100) if seed_ev.get('safe_upper_bound_J') and ev.get('safe_upper_bound_J') else None,
            rootlp_last_callback=root[-1] if root else None,
            first_post_root_callback=after[0] if after else None,
            root_completion_timing_scope='first later-phase callback is an observed upper bound on root completion, not an exact internal completion time',
            last_solver_reported_bound=bounds[-1] if bounds else None,
            callback_count=len(callbacks),
            solver_candidate_evaluations=len(evals),solver_complete_SAFE_evaluations=sum(e.get('accepted_safe') is True for e in evals),
            candidate_identity_rows=candidate_identity_rows,
            initial_evaluations=sum(isinstance(e.get('evaluation'),dict) for e in seed_attempts),
            native_requests=r.get('solver_request_attempts'),native_return_receipts=s.get('native_returns'),raw_native_files=native,
            method_elapsed_s=t['method_elapsed_s'],deadline_overshoot_s=t.get('deadline_overshoot_s'),cleanup_s=t.get('cleanup_s'),total_process_s=s.get('total_process_elapsed_s'),
            cleanup_status=cleanup.get('cleanup_status'),cleanup_complete=s.get('cleanup_complete'),
            construction_components=c.get('construction_components'),construction_phase_wall_seconds=c.get('phase_wall_seconds'),
            python_memory=c.get('memory'),phases_exclusive_s=p,unattributed_s=t.get('unattributed_s'),
            scientific_cutoff_s=300,source_integrity=s.get('source_integrity_after'),
            solver_bounds_independently_certified=False,optimality_proven=False)
        metrics.append(m)
    if len(metrics)==2 and all('initial_candidate_sha256' in m for m in metrics):
        check('common_seed_candidate',metrics[0]['initial_candidate_sha256']==metrics[1]['initial_candidate_sha256'])
        check('common_seed_energy',metrics[0]['initial_upper_bound_J']==metrics[1]['initial_upper_bound_J'])
        left=summary['results'][0]['flags'];right=summary['results'][1]['flags']
        check('only_joint_state_switch_changes',[k for k in left if left[k]!=right[k]]==['prune_joint_states'])
        a=read(PAIR/'off/method/input_instance.json');b=read(PAIR/'on/method/input_instance.json')
        check('identical_input',a==b)
        check('identical_config',read(PAIR/'off/method/input_config.json')==read(PAIR/'on/method/input_config.json'))
        native_options=[m.get('raw_native_files') for m in metrics]
        if all(native_options):
            left=native_options[0][0]['options'];right=native_options[1][0]['options']
            check('same_non_time_native_options',{k:v for k,v in left.items() if k!='MaxTime'}=={k:v for k,v in right.items() if k!='MaxTime'})
    result=dict(analysis='Read-only from archived receipts, no new solver/model/thermal calls',checks=checks,passed=all(c['passed'] for c in checks),metrics=metrics)
    (OUT/'audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    (OUT/'callbacks.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(dict(passed=result['passed'],check_count=len(checks),failures=[c for c in checks if not c['passed']],metrics=[{k:v for k,v in m.items() if k not in ('model','construction_components','construction_phase_wall_seconds','phases_exclusive_s','raw_native_files','native_return_receipts')} for m in metrics]),ensure_ascii=False,indent=2))

if __name__=='__main__': analyze()
