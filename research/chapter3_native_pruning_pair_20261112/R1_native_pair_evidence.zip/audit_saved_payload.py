"""Inspect saved native payloads only. No solve, build, or thermal call."""
from collections import defaultdict
from pathlib import Path
import hashlib
import json
import numpy as np
from scipy.io import loadmat

root=Path(__file__).resolve().parent
results=[]
for arm in ['off','on']:
    path=root/'execution/pair'/arm/'method/matlab/request_000001.mat'
    d=loadmat(path)
    A=d['A'].tocsr(); A.sort_indices()
    b=d['b'].reshape(-1);x=d['x0'].reshape(-1)
    eq=d['Aeq'].tocsr();beq=d['beq'].reshape(-1)
    lb=d['lb'].reshape(-1);ub=d['ub'].reshape(-1);ints=d['intcon'].reshape(-1).astype(int)-1
    groups=defaultdict(lambda: [[],[]])
    pairs=[]
    for i in range(A.shape[0]):
        lo,hi=A.indptr[i:i+2]; v=A.data[lo:hi]
        if not len(v): continue
        sign=1 if v[0]>0 else -1
        key=hashlib.sha256(A.indices[lo:hi].astype('<i8').tobytes()+(v*sign).astype('<f8').tobytes()+np.array([b[i]*sign if b[i] else 0.0],dtype='<f8').tobytes()).digest()
        bucket=groups[key]
        opposite=bucket[0 if sign<0 else 1]
        if opposite:
            j=opposite.pop();jl,jh=A.indptr[j:j+2]
            assert np.array_equal(A.indices[lo:hi],A.indices[jl:jh])
            assert np.array_equal(v,-A.data[jl:jh]) and b[i]==-b[j]
            pairs.append([j,i])
        else:bucket[0 if sign>0 else 1].append(i)
    residual=A@x-b
    checks=dict(inequality_max_positive=float(max(0,np.max(residual,initial=0))),equality_max_absolute=float(np.max(np.abs(eq@x-beq),initial=0)),lower_max_positive=float(max(0,np.max(lb-x,initial=0))),upper_max_positive=float(max(0,np.max(x-ub,initial=0))),integer_max_absolute=float(np.max(np.abs(x[ints]-np.rint(x[ints])),initial=0)))
    result=dict(arm=arm,payload_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),variables=A.shape[1],inequality_rows=A.shape[0],equality_rows=eq.shape[0],strict_opposite_row_pairs=len(pairs),binary64_x0_residuals=checks,strict_opposite_pairs_zero_based=pairs,scope='Exact binary64 coefficient/RHS opposite-pair identity checked with array equality; x0 residuals are floating-point admission checks, not exact feasibility certificates. No representation modified or solver rerun.')
    results.append(result)
out=dict(results=results,scientific_calls=0,interpretation='Both actual payloads use paired inequalities with no explicit equalities. Prior repository diagnostics make exact equality representation a plausible next controlled diagnostic, but this read-only audit does not establish the cause of ON exitflag -2.')
(root/'analysis/saved_payload_audit.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
print(json.dumps([{k:v for k,v in r.items() if k!='strict_opposite_pairs_zero_based'} for r in results],indent=2))
