"""No scientific call: test taskkill on only a newly created Python tree."""
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import psutil

root = Path(__file__).resolve().parent
out = root / 'cleanup_preflight'
out.mkdir(exist_ok=False)
child_script = out / 'owned_parent.py'
child_script.write_text('import subprocess, sys, time\np=subprocess.Popen([sys.executable,"-c","import time;time.sleep(90)"], creationflags=getattr(subprocess,"CREATE_NO_WINDOW",0))\nprint(p.pid,flush=True)\ntime.sleep(90)\n')
with (out/'stdout.log').open('x') as log:
    proc = subprocess.Popen([sys.executable, '-B', str(child_script)], stdout=log, stderr=log, creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
parent = psutil.Process(proc.pid)
created = parent.create_time()
children = []
for _ in range(100):
    children = parent.children(recursive=True)
    if children: break
    time.sleep(.05)
assert children, 'No owned child appeared'
identities = [(p.pid,p.create_time()) for p in [parent,*children]]
assert parent.create_time() == created
killed = subprocess.run(['taskkill','/PID',str(proc.pid),'/T','/F'], capture_output=True, timeout=15)
proc.wait(timeout=15)
gone, alive = psutil.wait_procs([parent,*children],timeout=10)
result = {'pid_create_time':identities,'taskkill_returncode':killed.returncode,'taskkill_stdout':killed.stdout.decode(errors='replace'),'taskkill_stderr':killed.stderr.decode(errors='replace'),'alive':[p.pid for p in alive],'passed':killed.returncode==0 and not alive,'solver_calls':0,'thermal_calls':0,'model_builds':0,'memory_available_bytes':psutil.virtual_memory().available}
(out/'result.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result))
sys.exit(0 if result['passed'] else 1)
