import subprocess, sys, time
p=subprocess.Popen([sys.executable,"-c","import time;time.sleep(90)"], creationflags=getattr(subprocess,"CREATE_NO_WINDOW",0))
print(p.pid,flush=True)
time.sleep(90)
