import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'pair_source'
ENTRY = SOURCE / 'research/chapter3_pruned_native_pair_delivery_20261111/run_pair.py'
OUT = ROOT / 'execution'

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('stage', choices=['test', 'probe', 'freeze', 'run'])
    stage = parser.parse_args().stage
    OUT.mkdir(exist_ok=True)
    temp = OUT / 'temp'
    temp.mkdir(exist_ok=True)
    env = dict(os.environ, TEMP=str(temp), TMP=str(temp), TMPDIR=str(temp))
    args = {
        'test': [str(ENTRY.with_name('test_entry.py')), str(OUT / 'precheck')],
        'probe': [str(ENTRY), 'probe', '--matlab', 'F:/Matlab2023/Program_Files/MATLAB_R2023b/bin/matlab.exe', '--out', str(OUT / 'probe')],
        'freeze': [str(ENTRY), 'freeze', '--probe', str(OUT / 'probe/environment_receipt.json'), '--plan', str(OUT / 'plan.json')],
        'run': [str(ENTRY), 'run', '--plan', str(OUT / 'plan.json'), '--out', str(OUT / 'pair'), '--execute'],
    }[stage]
    command = [sys.executable, '-B', *args]
    receipt = dict(stage=stage, argv=command, cwd=str(SOURCE), started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), temporary_directory=str(temp))
    receipt_path = OUT / (stage + '.command.json')
    with receipt_path.open('x', encoding='utf-8') as f:
        json.dump(receipt, f, indent=2)
    start = time.monotonic()
    with (OUT / (stage + '.stdout.log')).open('x') as stdout, (OUT / (stage + '.stderr.log')).open('x') as stderr:
        proc = subprocess.Popen(command, cwd=SOURCE, env=env, stdout=stdout, stderr=stderr, creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
        receipt['pid'] = proc.pid
        code = proc.wait()
    receipt.update(returncode=code, wall_s=time.monotonic()-start, ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    with (OUT / (stage + '.completed.json')).open('x', encoding='utf-8') as f:
        json.dump(receipt, f, indent=2)
    print(json.dumps(receipt))
    if code:
        print((OUT / (stage + '.stderr.log')).read_text(errors='replace')[-5000:])
    return code

if __name__ == '__main__':
    sys.exit(main())
