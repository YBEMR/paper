from pathlib import Path
import hashlib
import json
import shutil
import zipfile

work=Path(__file__).resolve().parent
out=work.parent/'outputs'
previous=work/'previous_attempt'
previous.mkdir(exist_ok=False)
old=Path('C:/Users/86130/Documents/Codex/2026-11-12/task/r1_native_20261112_0147')
for src,name in [(old/'RESULT.txt','RESULT.txt'),(old/'pair_run01/pair_summary.json','pair_summary.json')]:
    shutil.copyfile(src,previous/name)
files=[]
excluded=[]
for folder in ['pair_source','execution','analysis','cleanup_preflight','precheck','previous_attempt']:
    for path in sorted((work/folder).rglob('*')):
        if not path.is_file():continue
        if any(part in ['isolated_matlab_preferences','temp','__pycache__','.runtime'] for part in path.relative_to(work).parts):
            excluded.append(str(path.relative_to(work)));continue
        files.append(path)
for name in ['execution_scope.json','recent_commits.json','execute_stage.py','check_owned_cleanup.py','analyze_pair.py','audit_saved_payload.py','analysis_stdout.log','analysis_stderr.log','payload_audit_stdout.log','payload_audit_stderr.log','package_results.py']:
    files.append(work/name)
report=out/'R1实验报告.txt'
entries=[(p,p.relative_to(work).as_posix()) for p in files]+[(report,report.name)]
manifest=dict(files=[dict(path=name,bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p,name in entries],excluded_non_scientific_runtime_files=excluded)
archive=out/'R1实验完整证据.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p,name in entries:z.write(p,name)
    z.writestr('MANIFEST_SHA256.json',json.dumps(manifest,ensure_ascii=False,indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for entry in manifest['files']:
        assert hashlib.sha256(z.read(entry['path'])).hexdigest()==entry['sha256'],entry['path']
receipt=dict(archive=archive.name,bytes=archive.stat().st_size,sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),verified_file_count=len(entries),all_archive_checksums_match=True)
(out/'交付校验.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(receipt,ensure_ascii=False))
