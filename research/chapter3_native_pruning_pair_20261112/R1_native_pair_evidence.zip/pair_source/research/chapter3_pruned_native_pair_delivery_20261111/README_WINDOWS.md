# Windows交接：完整auto-L R1，支持传播均ON，仅联合状态剪枝OFF/ON

本包基于 `fa8e8de0166c1ee8d0ffaaa447122ba8f69014b3`。217份原科学源码及输入保持原哈希，新增专用入口和预算适配层。准备阶段仅运行模拟测试，未构模、热评价或调用MILP。当前包是可验证的交接材料，不冒充Windows原生验收通过。应在已经连接的 `DESKTOP-0MMHPAK` 可见Work环境执行下面步骤并保存完整输出。

## 内容和验收

- `bundle_manifest.json`：逐文件SHA256、原提交、输入、baseline flags、300秒、两个arm。
- `research/chapter3_pruned_native_pair_delivery_20261111/run_pair.py`：verify/probe/freeze/run入口；默认无求解，只有显式 `run --execute` 执行正式配对。
- `pair_lifecycle.py`：原method_runner生命周期的受控副本，仅增加已有外部budget参数、限制/时钟一致性检查和计时标签。AST测试逐段核对其余执行逻辑不变。217份原科学文件不修改。
- `test_entry.py`、测试回执及本说明：可在目标Python运行，无MATLAB求解。

先校验传输ZIP SHA256，解压到新的可写目录，避免覆盖旧运行。包内目录必须完整保留。用户已转达目标Python3.12.4、NumPy1.26.4、SciPy1.13.1；入口仅使用兼容Python3.12的接口，保留原数值源码，但Cloud测试版本为3.12.14/2.3.5/1.17.0，不能冒充目标版本实测。还需既有psutil；缺依赖先报告，不自动安装或替换求解器。实际依赖版本、CPU数和线程环境会进入冻结身份。严禁直接运行旧support OFF/ON入口。

以下在解压后的包根目录PowerShell中执行。路径变量按实际解压位置设置；输出文件/目录必须全新。

```powershell
$entry = "research/chapter3_pruned_native_pair_delivery_20261111/run_pair.py"
python -B $entry verify
python -B research/chapter3_pruned_native_pair_delivery_20261111/test_entry.py local_precheck01
python -B $entry probe --matlab "F:/Matlab2023/Program_Files/MATLAB_R2023b/bin/matlab.exe" --out local_probe01
python -B $entry freeze --probe local_probe01/environment_receipt.json --plan local_pair_plan01.json
```

`probe`只启动并关闭原MATLAB桥，不发出intlinprog请求；保留版本、许可、intlinprog路径和进程清理回执。其90秒是环境检查上限，不是正式方法预算。失败回执也保存。freeze要求24小时内、同一Windows环境、R2023b、许可成功、清理完成和源/可执行哈希一致。每组方法仍独立启动MATLAB，不能复用probe进程。

probe、OFF、ON分别使用各自输出目录中的 `isolated_matlab_preferences/.runtime/matlab_prefs`。适配器仅在单线程构造MATLAB桥期间临时定位其REPO（冻结源码中该变量只用于偏好目录），随后无论成功失败均恢复；MATLAB源文件HERE、原生选项与数值逻辑不变。没有修改用户全局环境或安装目录。系统页缓存仍可能受probe和固定顺序影响。

确认本机检查通过后，按用户既有授权仅执行一次：

```powershell
python -B $entry run --plan local_pair_plan01.json --out local_pair_run01 --execute > local_pair_run01.stdout.log 2> local_pair_run01.stderr.log
```

不重新freeze换文件名以绕过已消费claim；任何失败均保留并报告，不自动重跑。旧结果从不覆盖。prepare任务未执行上述probe或run。

## 时钟、初解和结果

每组父进程在创建slot记录、启动独立Python前取系统monotonic起点，将该绝对起点传给worker。同机Python的跨进程monotonic时钟由测试/目标环境复核；正式budget为该起点＋300秒，不重置。解释器/导入、源码与环境核验、输入读取、所有构模及严格认证、现场初解及完整连续电热评价、x0补全/原行残差检查、MATLAB启动/导出/求解/解码/回调评价均共享该deadline。准备/导入部分计入总时间的unattributed项，并另有PREPARATION_COMPLETE事件。

两组均 `propagate_support=True`；只切 `prune_joint_states=False/True`。保留原baseline flags、原conditional热反馈流程、原intlinprog算法/容差/预处理配置。每组独立空Model缓存。

初解是原 `deterministic-initial-schedule-v1` 构造规则，最多3个固定顺序模板，首个完整SAFE后补全x0；它不是增强HEFT。OFF和ON各自生成并支付全部成本。OFF仅向ON传递已验证候选的哈希；ON实际初解、评价身份、x0解码及实际原矩阵数值接纳必须吻合，之后才允许发出首个原生请求。绝不传递方案、向量或SAFE回执作为初始化输入。若OFF缺可靠初解，停止ON；若ON身份不一致，保存其失败并停止，无自动无x0后备分支。

300秒后允许仅清理和序列化既有证据。380秒watchdog只是进程回收保护，不增加求解/评价预算；没有额外60秒后验评价额度。恰好300秒完成的SAFE不计入。原生命周期可能合作式超时，记录真实overshoot；墙钟运行不是硬实时截止。已有预算内SAFE可在超时后归档，迟到候选或未完成评价不升格为SAFE。

`slot_result.json` 提取原回执、候选身份、是否等于初解、callback/return状态和下界原始字段。根LP结果若日志没有明确提供就保持null；不将中间目标推断成有效下界。完整证据仍在每组 `method/result.json`、`diagnostic_events.jsonl`、`initial_receipt_checkpoint.json`、`matlab/matlab.log`、`request_*.event_*.json`、request/response文件和timing中。未收到完整最终返回不能记为最优/不可行。

两个worker严格顺序执行，同机/同Python依赖和线程环境进入计划并在每组核查。已知Windows可用内存约2.51–3.02GiB：冻结、启动前和worker准备完成均记录物理可用内存，保留已有构模峰值观测；不并行、不扩大模型、不增加内存密集的原始矩阵副本归档。Cloud约311MiB的Python静态峰值不预测MATLAB原生求解峰值。内存不足/原生崩溃保留失败，不补跑、不增加预算；未知的原生峰值如实标未测。独立偏好目录不清除系统页缓存，未声称独占整机或统计性能显著。结果只能解释单个R1、一次配对；同一电热评价器复核不属于独立实现。
