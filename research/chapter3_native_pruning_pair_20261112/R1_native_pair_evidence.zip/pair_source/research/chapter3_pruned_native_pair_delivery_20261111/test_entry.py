"""Deterministic fake-clock/worker tests. No model, thermal or native solve."""
import ast
from copy import deepcopy
from datetime import datetime,timezone
import io
import json
from pathlib import Path
import sys
import tempfile
import time
from types import SimpleNamespace
import unittest
from unittest.mock import patch

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
sys.path.insert(0,str(ROOT/'research/chapter3_experiments'))
import run_pair as r
import pair_lifecycle as lifecycle
from diagnostic_search import Recorder
from thermal import Exhausted


class Clock:
    def __init__(self,t=10):self.t=t
    def __call__(self):return self.t
    def advance(self,n):self.t+=n


def seed(candidate=None):
    candidate=candidate or {'scenes':{'A':[]}}
    ev=dict(state='SAFE',rankable_energy=True,safe_upper_bound_J='1',completed_at_elapsed_s=25,
        evidence_identity=dict(input_sha256='input',candidate_sha256=r.digest(candidate)))
    return dict(state='SAFE_POINT_READY',witness=dict(candidate=candidate,evaluation=ev),
        completion=dict(state='INITIAL_POINT_READY',decoded_roundtrip=True,
            numerical_acceptance=dict(accepted_numerically=True),completed_at_s=26))


class Observer:
    def __init__(self,*args):self.finished_at=None
    def finish(self,*args):self.finished_at=1;return {}
    def snapshot(self):return {}


class Tests(unittest.TestCase):
    def test_switches_only_joint_pruning(self):
        m={'baseline_flags':{'prefilter_deadlines':True,'strengthen_energy_lower_bounds':True}}
        a,b=r.flags(m,'off'),r.flags(m,'on')
        self.assertTrue(a['propagate_support'] and b['propagate_support'])
        self.assertEqual([k for k in a if a[k]!=b[k]],['prune_joint_states'])
        self.assertRaises(ValueError,r.flags,m,'old_on')

    def test_lifecycle_exact_body_except_external_budget(self):
        old=ast.parse((HERE/'method_runner.before.txt').read_text())
        new=ast.parse((HERE/'pair_lifecycle.py').read_text())
        a=next(n for n in old.body if isinstance(n,ast.FunctionDef) and n.name=='execute_milp')
        b=next(n for n in new.body if isinstance(n,ast.FunctionDef) and n.name=='execute_milp')
        a.args=b.args
        # Only the explicitly reviewed budget assignment/guard and clock label differ.
        b.body[1]=a.body[1];del b.body[2]
        final=next(n for n in b.body if isinstance(n,ast.Try)).finalbody
        label=next(n for n in final if isinstance(n,ast.If) and ast.unparse(n.test)=='method_budget is not None')
        final.remove(label)
        self.assertEqual(ast.dump(a,include_attributes=False),ast.dump(b,include_attributes=False))

    def test_parent_clock_import_cost_and_exact_cutoff(self):
        c=Clock(20);b=r.anchor_budget(0,c)
        self.assertEqual(b.elapsed,20);self.assertEqual(b.remaining,280)
        c.t=300;self.assertRaises(Exhausted,b.check)
        self.assertRaises(ValueError,r.anchor_budget,301,c)

    def exercise_lifecycle(self,folder,expire=None):
        c=Clock(20);b=r.anchor_budget(0,c);seen=[]
        def loader(budget):seen.append(budget);c.advance(1);return {'accuracy_targets':{}},{'id':'mock'}
        def builder(instance,config,budget,progress):
            seen.append(budget);c.advance(301 if expire=='build' else 2)
            return SimpleNamespace(summary=lambda:{},instance=instance)
        class Session:
            counter=0
            def __init__(self,path,total_budget_s,budget):
                seen.append(budget);self.remaining=total_budget_s;c.advance(3)
            def close(self):c.advance(2)
        def solve(model,session,accuracy,budget):
            seen.append(budget);self.assertEqual(budget.deadline,300)
            c.advance(301 if expire=='solve' else 4);budget.check()
            return {'state':'UNRESOLVED','reason':'NO_INTEGER_CANDIDATE'}
        with patch.object(lifecycle,'BuildObserver',Observer):
            value=lifecycle.execute_milp(loader,folder,seconds=300,construct_only=False,
                clock=c,model_builder=builder,session_factory=Session,solve=solve,method_budget=b)
        self.assertTrue(all(x is b for x in seen));return value,seen

    def test_full_lifecycle_no_budget_reset(self):
        with tempfile.TemporaryDirectory() as t:
            value,seen=self.exercise_lifecycle(Path(t)/'method')
            self.assertEqual(len(seen),4);self.assertEqual(value['timing']['method_elapsed_s'],30)
            self.assertEqual(value['timing']['cleanup_s'],2)
            self.assertIn('parent launch',value['timing']['clock_origin'])

    def test_build_expiry_never_starts_session(self):
        with tempfile.TemporaryDirectory() as t:
            value,seen=self.exercise_lifecycle(Path(t)/'method','build')
            self.assertEqual(len(seen),2);self.assertFalse(value['solver_started']);self.assertTrue(value['budget_exhausted'])

    def test_solver_expiry_has_no_safe_result(self):
        with tempfile.TemporaryDirectory() as t:
            value,seen=self.exercise_lifecycle(Path(t)/'method','solve')
            self.assertFalse(r.accepted_summary(value)['accepted_in_budget_safe'])

    def test_wrong_external_budget_rejected(self):
        c=Clock();b=r.anchor_budget(0,c)
        with tempfile.TemporaryDirectory() as t:
            self.assertRaises(ValueError,lifecycle.execute_milp,None,Path(t)/'m',seconds=301,clock=c,method_budget=b)

    def test_fresh_seed_guard_identity_and_admission(self):
        s=seed();h=r.digest(s['witness']['candidate'])
        self.assertEqual(r.validate_seed(s,'input',h)['candidate_sha256'],h)
        for change in [lambda x:x['witness']['evaluation'].update(completed_at_elapsed_s=300),
            lambda x:x['completion'].update(completed_at_s=300),
            lambda x:x['completion']['numerical_acceptance'].update(accepted_numerically=False),
            lambda x:x['witness']['evaluation'].update(evidence_identity={})]:
            bad=deepcopy(s);change(bad);self.assertRaises(ValueError,r.validate_seed,bad,'input',h)
        self.assertRaises(ValueError,r.validate_seed,s,'input','other-arm-seed')

    def test_actual_vector_checked_before_native_call(self):
        with tempfile.TemporaryDirectory() as t:
            p=Path(t);s=seed();r.save(p/'checkpoint.json',{'initialisation':s});calls=[]
            native=SimpleNamespace(solve=lambda *a,**k:calls.append(k) or {'x':[]},event_consumer=None)
            c=Clock(27);b=r.anchor_budget(0,c)
            g=r.Guard(native,p/'checkpoint.json','input',None,lambda x:s['witness']['candidate'],
                lambda *a,**kw:{'x0_validation':{'accepted_numerically':True}},p)
            g.solve({},budget=b,x0=[1]);self.assertEqual(len(calls),1);self.assertEqual(g.record['status'],'PASSED')
            c.t=300;self.assertRaises(Exhausted,g.solve,{},budget=b,x0=[1]);self.assertEqual(len(calls),1)

    def test_bad_actual_x0_stops_without_native(self):
        with tempfile.TemporaryDirectory() as t:
            p=Path(t);r.save(p/'checkpoint.json',{'initialisation':seed()});calls=[]
            native=SimpleNamespace(solve=lambda *a,**k:calls.append(1),event_consumer=None)
            g=r.Guard(native,p/'checkpoint.json','input',None,lambda x:{'wrong':1},lambda *a,**k:{},p)
            self.assertRaises(ValueError,g.solve,{},budget=r.anchor_budget(0,Clock(27)),x0=[1])
            self.assertFalse(calls);self.assertEqual(g.record['status'],'REJECTED')

    def test_safe_boundary_and_returned_initial(self):
        s=seed();candidate=s['witness']['candidate'];ev=s['witness']['evaluation']
        result=dict(state='SAFE',safe_candidate=candidate,evaluation=ev,initialisation=s)
        summary=r.accepted_summary(result);self.assertTrue(summary['equals_initial']);self.assertFalse(summary['solver_improvement_claimed'])
        for v in [300,301,None,float('nan'),float('inf'),True,-1]:
            bad=deepcopy(result);bad['evaluation']['completed_at_elapsed_s']=v
            self.assertFalse(r.accepted_summary(bad)['accepted_in_budget_safe'])

    def test_real_recorder_rejects_late_evaluation(self):
        with tempfile.TemporaryDirectory() as t:
            c=Clock(299);b=r.anchor_budget(0,c)
            def evaluator(*args):
                c.t=301;return dict(state='SAFE',rankable_energy=True,safe_upper_bound_J='1',completed_at_elapsed_s=301)
            recorder=Recorder(SimpleNamespace(),{},b,Path(t),decoder=lambda *a:{'scenes':{}},evaluator=evaluator)
            recorder.assess([1],'mock_final');self.assertIsNone(recorder.best)
            self.assertFalse(recorder.evaluations[0]['accepted_safe'])

    def test_real_recorder_expired_candidate_never_decodes(self):
        with tempfile.TemporaryDirectory() as t:
            b=r.anchor_budget(0,Clock(300));calls=[]
            recorder=Recorder(SimpleNamespace(),{},b,Path(t),decoder=lambda *a:calls.append(1))
            self.assertRaises(Exhausted,recorder.assess,[1],'late_native');self.assertFalse(calls)

    def test_manifest_drift_and_path_escape(self):
        with tempfile.TemporaryDirectory() as t:
            p=Path(t);(p/'source.py').write_text('x=1')
            r.save(p/'bundle_manifest.json',dict(schema=r.SCHEMA,seconds=300,arms=['off','on'],files={'source.py':r.sha(p/'source.py')}))
            r.verify(p);(p/'source.py').write_text('x=2');self.assertRaises(ValueError,r.verify,p)
            for s in ['../x','C:/x','/x','a\\b']:self.assertRaises(ValueError,r.safe_path,p,s)

    def test_controller_no_execute_no_worker(self):
        with patch.object(r.subprocess,'Popen') as proc:
            self.assertRaises(ValueError,r.run,'none','none',False);proc.assert_not_called()

    def controller(self,p,mode='normal'):
        import psutil
        plan=p/'plan.json';plan.write_text('{}');spawn=[]
        class Proc:
            pid=12345
            def __init__(self,argv,**kw):
                spawn.append(argv);out=Path(argv[argv.index('--out')+1]);out.mkdir();arm=argv[argv.index('--arm')+1]
                r.save(out/'slot_result.json',dict(arm=arm,status='FINISHED',cleanup_complete=True,
                    source_integrity_after=True,technical_error=mode=='error',
                    seed_guard=dict(status='PASSED',candidate_sha256='same_fresh_hash')))
            def wait(self,timeout):
                if mode=='timeout':raise r.subprocess.TimeoutExpired('mock',timeout)
                return 0
        with patch.object(r,'check_plan',return_value=({'watchdog_s':380},{})),\
             patch.object(r.subprocess,'Popen',Proc),patch.object(psutil,'Process',return_value=SimpleNamespace(create_time=lambda:1)),\
             patch.object(r,'memory_observation',return_value={'scope':'mock'}),\
             patch.object(r,'kill_owned',return_value={'complete':True}) as kill:
            result=r.run(plan,p/'run',True)
            self.assertRaises(FileExistsError,r.run,plan,p/'second',True)
        return result,spawn,kill

    def test_controller_exact_two_and_identity_only_transfer(self):
        with tempfile.TemporaryDirectory() as t:
            result,calls,kill=self.controller(Path(t))
            self.assertEqual(len(calls),2);self.assertNotIn('--expected-seed',calls[0]);self.assertIn('same_fresh_hash',calls[1])
            self.assertTrue(result['pair_initialization_and_cleanup_valid']);kill.assert_not_called()

    def test_controller_error_stops_no_retry(self):
        with tempfile.TemporaryDirectory() as t:
            result,calls,kill=self.controller(Path(t),'error');self.assertEqual(len(calls),1)
            self.assertEqual(result['omitted_arms'],['on']);self.assertFalse(result['pair_initialization_and_cleanup_valid'])

    def test_watchdog_is_not_extra_method_budget(self):
        with tempfile.TemporaryDirectory() as t:
            result,calls,kill=self.controller(Path(t),'timeout');self.assertEqual(len(calls),1);kill.assert_called_once()
            self.assertFalse(result['pair_initialization_and_cleanup_valid']);self.assertEqual(r.LIMIT,300)

    def test_windows_probe_required_before_freeze(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t);exe=root/'matlab.exe';exe.write_bytes(b'mock exe');(root/'bundle_manifest.json').write_text('{}')
            environment={'host':'TEST_WINDOWS','system':'Windows'}
            receipt=dict(created_utc=datetime.now(timezone.utc).isoformat(),environment=environment,
                ready=dict(release='2023b',license_checkout=True,intlinprog_path='mock'),cleanup_complete=True,
                matlab=str(exe),matlab_sha256=r.sha(exe),manifest_sha256=r.sha(root/'bundle_manifest.json'))
            source=root/'probe.json';r.save(source,receipt)
            with patch.object(r,'ROOT',root),patch.object(r,'verify',return_value={'base_commit':'mock'}),\
                 patch.object(r,'environment',return_value=environment),patch.object(r.platform,'system',return_value='Windows'):
                p=r.freeze(source,root/'plan.json');self.assertEqual(p['seconds'],300);self.assertEqual(p['extra_post_budget_evaluation_s'],0)
                bad=deepcopy(receipt);bad['ready']['release']='2024a';r.save(root/'bad.json',bad)
                self.assertRaises(ValueError,r.freeze,root/'bad.json',root/'badplan.json')

    def test_full_worker_actual_wiring_two_switches_and_seed_policy(self):
        import milp,matlab_bridge,initial_point
        for arm in ['off','on']:
            with self.subTest(arm=arm),tempfile.TemporaryDirectory() as t:
                root=Path(t);out=root/arm;plan=root/'plan.json';r.save(plan,{})
                start=time.monotonic()-2
                r.save(str(plan)+'.claim.json',dict(token='mock',output=str(root)))
                r.save(root/(arm+'_claim.json'),dict(start_monotonic=start,token='mock',expected_seed=None))
                r.save(root/'instance.json',{'id':'mock'});r.save(root/'config.json',{'accuracy_targets':{}})
                seen=[];candidate=seed()['witness']['candidate']
                manifest=dict(baseline_flags={'prefilter_deadlines':True},instance_file='instance.json',config_file='config.json')
                def build(instance,config,**kw):
                    seen.append(kw);self.assertTrue(kw['propagate_support']);self.assertEqual(kw['prune_joint_states'],arm=='on')
                    return SimpleNamespace(summary=lambda:{})
                class Session:
                    counter=0;event_consumer=None;cleanup={}
                    def __init__(self,path,**kw):self.workdir=path;self.budget=kw['budget']
                    def close(self):pass
                    def solve(self,payload,**kw):self.counter+=1;return {'x':[]}
                def initial(model,session,accuracy,budget,**kw):
                    self.assertEqual(kw['max_attempts'],3)
                    self.assertEqual(kw['diagnostic_solver'].keywords,{'feedback_kind':'conditional'})
                    v=seed(candidate);v['witness']['evaluation']['completed_at_elapsed_s']=1
                    v['completion']['completed_at_s']=1.1
                    v['witness']['evaluation']['evidence_identity']['input_sha256']=r.digest({'id':'mock'})
                    kw['checkpoint'](v);session.solve({},budget=budget,x0=[1])
                    return dict(state='SAFE',safe_candidate=candidate,evaluation=v['witness']['evaluation'],initialisation=v)
                with patch.object(r,'ROOT',root),patch.object(r,'check_plan',return_value=({'matlab':'mock'},manifest)),\
                     patch.object(r,'verify',return_value=manifest),patch.object(milp,'build_model',side_effect=build),\
                     patch.object(milp,'decode',return_value=candidate),patch.object(matlab_bridge,'MatlabSession',Session),\
                     patch.object(matlab_bridge,'cleanup_is_complete',return_value=True),\
                     patch.object(matlab_bridge,'_prepare',return_value={'x0_validation':{'accepted_numerically':True}}),\
                     patch.object(initial_point,'solve_with_initial_witness',side_effect=initial),\
                     patch.object(lifecycle,'BuildObserver',Observer):
                    result=r.worker(plan,arm,out,start,'mock',None)
                self.assertEqual(result['status'],'FINISHED',result)
                self.assertEqual(result['seed_guard']['status'],'PASSED')
                self.assertTrue(result['accepted_in_budget_safe']);self.assertTrue(result['equals_initial']);self.assertEqual(len(seen),1)

    def test_future_seed_receipt_rejected(self):
        with tempfile.TemporaryDirectory() as t:
            p=Path(t);r.save(p/'checkpoint.json',{'initialisation':seed()})
            g=r.Guard(SimpleNamespace(),p/'checkpoint.json','input',None,None,None,p)
            self.assertRaises(ValueError,g.solve,{},budget=r.anchor_budget(0,Clock(20)),x0=[1])

    def test_isolated_preferences_restore_on_success_and_failure(self):
        import matlab_bridge
        old=matlab_bridge.REPO;seen=[]
        def construct(path,**kwargs):seen.append(matlab_bridge.REPO);return 'mock-session'
        with tempfile.TemporaryDirectory() as t:
            root=Path(t)
            with patch.object(matlab_bridge,'MatlabSession',side_effect=construct):
                for arm in ['probe','off','on']:
                    self.assertEqual(r.isolated_session(root/arm/'matlab'),'mock-session')
                    self.assertEqual(matlab_bridge.REPO,old)
            self.assertEqual(len(set(seen)),3)
            with patch.object(matlab_bridge,'MatlabSession',side_effect=RuntimeError('mock failure')):
                self.assertRaises(RuntimeError,r.isolated_session,root/'failed'/'matlab')
                self.assertEqual(matlab_bridge.REPO,old)
        tree=ast.parse((ROOT/'research/chapter3_experiments/matlab_bridge.py').read_text())
        refs=[n for n in ast.walk(tree) if isinstance(n,ast.Name) and n.id=='REPO']
        self.assertEqual(len(refs),2,'REPO has additional uses; isolated preference scope must be reviewed')


if __name__=='__main__':
    out=Path(sys.argv[1]);out.mkdir(parents=True,exist_ok=False)
    started=utc=datetime.now(timezone.utc).isoformat();began=time.monotonic()
    stream=io.StringIO();suite=unittest.defaultTestLoader.loadTestsFromTestCase(Tests)
    result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
    (out/'unittest.log').write_text(stream.getvalue())
    r.save(out/'results.json',dict(started_utc=started,ended_utc=datetime.now(timezone.utc).isoformat(),wall_s=time.monotonic()-began,
        tests=result.testsRun,passed=result.wasSuccessful(),failures=len(result.failures),errors=len(result.errors),
        native_calls=0,thermal_calls=0,model_builds=0,scope='Mock lifecycle/clock/worker and real receipt logic; no native Windows acceptance'))
    print(stream.getvalue());sys.exit(0 if result.wasSuccessful() else 1)
