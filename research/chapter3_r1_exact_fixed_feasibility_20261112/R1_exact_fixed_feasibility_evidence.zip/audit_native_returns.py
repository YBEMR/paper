"""Post-run exact arithmetic only; no numerical solve or physical evaluation."""
from pathlib import Path
import json,numpy as np
from exact_audit import ROOT,read,save,payload,audit,eq
from fixed_diagnostic import verify_plan
plan=verify_plan();out=ROOT/'native_exact_audit';out.mkdir(exist_ok=False)
cert=read(ROOT/'prepared/fixed_representation_certificate.json')
original=payload(ROOT/'prepared/original.mat');equalities=payload(ROOT/'prepared/equalities.mat')
eq.verify_equivalence(original,equalities,cert)
results={}
for label in plan['representations']:
    folder=ROOT/'runs'/label;receipt=read(folder/'receipt.json');raw=read(folder/'matlab/request_000001.response.json')
    assert all(receipt['checks'].values()) and receipt['native_calls']==1
    x=np.asarray(raw.get('x',[]),dtype=np.float64)
    if len(x)!=len(original['c']) or not np.isfinite(x).all():
        results[label]=dict(state='NO_FINITE_COMPLETE_VECTOR',strict_feasibility='UNKNOWN');continue
    # Same rows and noninteger bounds in original and fixed problems. Explicitly
    # checking fixed bounds also checks the weaker original bounds.
    record={}
    for representation,mat in [('original',original),('equalities',equalities)]:
        record[representation]=audit(mat,x,out/label/representation,label+'_return_vs_fixed_'+representation)
    ints=original['intcon'];unfixed=payload(ROOT/'sources/original/matlab/request_000001.mat')
    exact_fixed=bool(np.array_equal(x[ints],original['x0'][ints]))
    assert np.all(original['lb']>=unfixed['lb']) and np.all(original['ub']<=unfixed['ub'])
    results[label]=dict(exitflag=raw['exitflag'],native_fval=raw['fval'],output=raw['output'],
        original_integer_assignment_exact=exact_fixed,checks=record,
        strict_feasible=exact_fixed and all(v['exact_feasible'] for v in record.values()),
        original_unfixed_bounds_implied_by_checked_fixed_bounds=True,
        exact_return_vector_scope='Each returned binary64 vector interpreted as exact rational values; no projection, rounding repair or new solve.')
    print(json.dumps(dict(label=label,exitflag=raw['exitflag'],strict_feasible=results[label]['strict_feasible'],violations={k:{t:v['rows'][t]['strict_violations'] for t in ['A','Aeq']} for k,v in record.items()})),flush=True)
save(out/'summary.json',results);verify_plan()
