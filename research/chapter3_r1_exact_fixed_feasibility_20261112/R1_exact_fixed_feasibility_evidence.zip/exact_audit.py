"""Exhaustive exact binary64-as-rational row, bound and integrality audit."""
from fractions import Fraction as Q
from pathlib import Path
import csv,hashlib,json,math,sys,time
import numpy as np
from scipy.io import loadmat
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'runtime'))
import exact_equalities as eq
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):
    with p.open('x',encoding='utf-8') as f:json.dump(v,f,ensure_ascii=False,indent=2,allow_nan=False)
def verify_freeze():
    assert sha(ROOT/'freeze.json')==(ROOT/'freeze.sha256').read_text().strip()
    for name,h in read(ROOT/'freeze.json')['files'].items():assert sha(ROOT/name)==h,name
def payload(path):
    d=loadmat(path,variable_names=list(eq.KEYS))
    p={k:d[k].tocsc() if k in ('A','Aeq') else d[k].reshape(-1) for k in eq.KEYS}
    raw=p['intcon'];assert np.isfinite(raw).all() and np.equal(raw,np.floor(raw)).all()
    p['intcon']=raw.astype(np.int64)-1
    return p
def exact_dot(values,indices,x):
    return sum((Q.from_float(float(v))*x[int(j)] for j,v in zip(indices,values)),Q(0))
def audit(p,vector,directory,label):
    directory.mkdir(parents=True,exist_ok=False);start=time.monotonic()
    x=[Q.from_float(float(v)) if not isinstance(v,Q) else v for v in vector]
    integers=set(int(i) for i in p['intcon']);n=len(x)
    assert len(integers)==len(p['intcon']) and all(0<=i<n for i in integers)
    lo=[Q.from_float(float(v)) for v in p['lb']];hi=[Q.from_float(float(v)) for v in p['ub']]
    cache={}
    def q(v):
        v=float(v)
        if v not in cache:cache[v]=Q.from_float(v)
        return cache[v]
    variables=[];bf=[];inf=[]
    with (directory/'all_variables.csv').open('x',encoding='utf-8',newline='') as f:
        w=csv.writer(f);w.writerow(['column_zero_based','column_matlab_1based','value_exact','lower_exact','upper_exact','lower_violation_exact','upper_violation_exact','integer_required','integer_exact'])
        for j,v in enumerate(x):
            lower=max(Q(0),lo[j]-v);upper=max(Q(0),v-hi[j]);ok=j not in integers or v.denominator==1
            w.writerow([j,j+1,str(v),str(lo[j]),str(hi[j]),str(lower),str(upper),j in integers,ok])
            if lower or upper:bf.append(j)
            if not ok:inf.append(j)
    stats={};all_worst=[];box_conflicts=[]
    for key,rhs_key in [('A','b'),('Aeq','beq')]:
        a=p[key].tocsr();b=p[rhs_key];counts=dict(rows=a.shape[0],strict_violations=0,float_violations=0,exact_violations_hidden_by_float=0,coefficient_ratio_ge_1e9=0,nonzero_below_1e9=0,near_dot_roundoff_scale=0)
        xf=np.array([float(v) for v in x]);floating=a@xf-b
        coeffmin=None;coeffmax=Q(0);maxres=Q(0);worst=None
        with (directory/(key+'_all_rows.csv')).open('x',encoding='utf-8',newline='') as f,(directory/(key+'_strict_violations.jsonl')).open('x',encoding='utf-8') as details:
            w=csv.writer(f);w.writerow(['row_zero_based','row_matlab_1based','residual_exact','residual_float64','strict_violation','nnz','coefficient_min_abs','coefficient_max_abs','coefficient_ratio','sum_abs_terms_exact','dot_roundoff_scale_estimate','risk_flags'])
            for i in range(a.shape[0]):
                sl=slice(a.indptr[i],a.indptr[i+1]);ix=a.indices[sl];av=a.data[sl]
                terms=[q(v)*x[int(j)] for j,v in zip(ix,av)];lhs=sum(terms,Q(0));res=lhs-q(b[i])
                strict=res>0 if key=='A' else res!=0;fv=floating[i]>0 if key=='A' else floating[i]!=0
                counts['strict_violations']+=int(strict);counts['float_violations']+=int(fv)
                counts['exact_violations_hidden_by_float']+=int(strict and not fv)
                mags=[abs(q(v)) for v in av if v!=0];mn=min(mags,default=Q(0));mx=max(mags,default=Q(0));ratio=mx/mn if mn else Q(0)
                if mn:coeffmin=mn if coeffmin is None else min(coeffmin,mn)
                coeffmax=max(coeffmax,mx);abssum=sum(map(abs,terms),Q(0))
                # Risk locator only, not a forward-error certificate for MATLAB's internal solver.
                u=Q(1,2**53);gamma=len(terms)*u/(1-len(terms)*u)
                roundscale=gamma*abssum+u*(abs(lhs)+abs(q(b[i])))
                flags=[]
                if ratio>=10**9:flags.append('coefficient_ratio_ge_1e9');counts[flags[-1]]+=1
                if mn and mn<Q(1,10**9):flags.append('nonzero_below_1e9');counts[flags[-1]]+=1
                if roundscale and abs(res)<=roundscale:flags.append('near_dot_roundoff_scale');counts[flags[-1]]+=1
                w.writerow([i,i+1,str(res),repr(float(floating[i])),strict,len(ix),str(mn),str(mx),str(ratio),str(abssum),float(roundscale),'|'.join(flags)])
                magnitude=max(Q(0),res) if key=='A' else abs(res)
                if magnitude>maxres:maxres=magnitude;worst=i
                # Exact row-box necessary condition with original integer columns fixed at x0.
                minlhs=sum((q(v)*(x[int(j)] if int(j) in integers else lo[int(j)] if v>0 else hi[int(j)]) for j,v in zip(ix,av)),Q(0))
                maxlhs=sum((q(v)*(x[int(j)] if int(j) in integers else hi[int(j)] if v>0 else lo[int(j)]) for j,v in zip(ix,av)),Q(0))
                if minlhs>q(b[i]) or (key=='Aeq' and maxlhs<q(b[i])):
                    box_conflicts.append(dict(matrix=key,row_zero_based=i,min_lhs=str(minlhs),max_lhs=str(maxlhs),rhs=str(q(b[i]))))
                if strict:
                    record=dict(matrix=key,row_zero_based=i,row_matlab_1based=i+1,residual_exact=str(res),residual_float=float(res),rhs_exact=str(q(b[i])),rhs_binary64_hex=float(b[i]).hex(),
                        terms=[dict(column_zero_based=int(j),column_matlab_1based=int(j)+1,coefficient_exact=str(q(v)),coefficient_binary64_hex=float(v).hex(),x_exact=str(x[int(j)]),term_exact=str(t)) for j,v,t in zip(ix,av,terms)])
                    details.write(json.dumps(record,ensure_ascii=False)+'\n')
        counts.update(maximum_violation_exact=str(maxres),maximum_violation_float=float(maxres),worst_row_zero_based=worst,
                      coefficient_min_abs_exact=str(coeffmin),coefficient_max_abs_exact=str(coeffmax))
        stats[key]=counts
    result=dict(label=label,variables=n,integer_variables=len(integers),rows=stats,bound_violating_columns=bf,integer_violating_columns=inf,
        fixed_integer_single_row_box_conflicts=box_conflicts,
        exact_feasible=not bf and not inf and all(v['strict_violations']==0 for v in stats.values()),
        scope='Exact rational interpretation of every saved binary64 value; violation of a particular vector is not proof that its fixed-integer continuous subproblem is infeasible.',
        scale_risk_scope='Row coefficient spread and dot-roundoff-scale flags locate risks only; they do not measure a solver basis condition number or establish the internal failure cause.',
        objective_exact=str(sum((q(c)*v for c,v in zip(p['c'],x)),Q(0))),elapsed_s=time.monotonic()-start)
    save(directory/'summary.json',result);return result
def main():
    verify_freeze();out=ROOT/'exact_initial_audit';out.mkdir(exist_ok=False)
    p=payload(ROOT/'sources/original/matlab/request_000001.mat');d=payload(ROOT/'sources/equalities/matlab/request_000001.mat')
    cert=read(ROOT/'sources/equalities/matlab/request_000001.equality_certificate.json')
    equivalence=eq.verify_equivalence(p,d,cert)
    initial=[]
    for label in ['original','equalities']:
        record=read(ROOT/'sources'/label/'initial_receipt_checkpoint.json')['initialisation']
        assert record['state']=='SAFE_POINT_READY'
        w=record['witness'];ev=w['evaluation']
        assert ev['state']=='SAFE' and ev['rankable_energy'] and all(s['complete'] and s['state']=='SAFE' for s in ev['scenes'].values())
        initial.append(w)
        native=loadmat(ROOT/'sources'/label/'matlab/request_000001.native.mat',variable_names=['initialPoint'])
        assert np.array_equal(native['initialPoint'].reshape(-1),p['x0'])
    assert initial[0]['candidate']==initial[1]['candidate']
    assert initial[0]['evaluation']['safe_upper_bound_J']==initial[1]['evaluation']['safe_upper_bound_J']
    save(out/'identity.json',dict(equivalence=equivalence,complete_SAFE_receipts_preserved=True,same_schedule=True,same_energy=True,native_received_x0_identical=True,
        SAFE_upper_bound_J=initial[0]['evaluation']['safe_upper_bound_J'],scope='Archived physical SAFE, no new physical evaluation; no semantic row-name reconstruction.'))
    result={}
    for label,mat in [('original',p),('equalities',d)]:
        result[label]=audit(mat,mat['x0'],out/label,label);print(json.dumps(result[label]),flush=True)
    save(out/'summary.json',result);verify_freeze()
if __name__=='__main__':main()
