"""One frozen two-representation fixed-integer continuous diagnostic, no retry."""
import time
ENTRY=time.monotonic()
from pathlib import Path
import argparse,hashlib,json,os,subprocess,sys,traceback
import numpy as np
from scipy.io import savemat
from exact_audit import ROOT,read,save,sha,payload,verify_freeze,eq

def fixed(p):
    d={k:v.copy() for k,v in p.items()};ix=p['intcon'];x=p['x0']
    assert np.equal(x[ix],np.floor(x[ix])).all()
    assert ((x[ix]>=p['lb'][ix])&(x[ix]<=p['ub'][ix])).all()
    d['lb'][ix]=x[ix];d['ub'][ix]=x[ix]
    assert np.array_equal(d['lb'][ix],d['ub'][ix])
    unchanged=['c','A','b','Aeq','beq','intcon','x0']
    before=eq._digest(p);after=eq._digest(d)
    assert all(before[k]==after[k] for k in unchanged)
    other=np.ones(len(x),dtype=bool);other[ix]=False
    assert np.array_equal(d['lb'][other],p['lb'][other]) and np.array_equal(d['ub'][other],p['ub'][other])
    return d

def prepare():
    verify_freeze()
    assert read(ROOT/'tests/result.json')['passed']
    audits=read(ROOT/'exact_initial_audit/summary.json')
    assert all(not v['integer_violating_columns'] and not v['bound_violating_columns'] for v in audits.values())
    dest=ROOT/'prepared';dest.mkdir(exist_ok=False)
    source=[];derived=[]
    for label in ['original','equalities']:
        p=payload(ROOT/'sources'/label/'matlab/request_000001.mat');d=fixed(p)
        native={k:v.copy() for k,v in d.items()};native['intcon']=(d['intcon']+1).astype(np.float64)
        savemat(dest/(label+'.mat'),native,do_compression=True,oned_as='column')
        assert eq._digest(payload(dest/(label+'.mat')))==eq._digest(d)
        source.append(p);derived.append(d)
    cert=read(ROOT/'sources/equalities/matlab/request_000001.equality_certificate.json')
    certificate=dict(cert,source_array_sha256=eq._digest(derived[0]),derived_array_sha256=eq._digest(derived[1]))
    certificate['checks']=eq.verify_equivalence(derived[0],derived[1],certificate)
    save(dest/'fixed_representation_certificate.json',certificate)
    baseline=read(ROOT/'sources/original/matlab/request_000001.response.json')['options']
    files={p.relative_to(ROOT).as_posix():sha(p) for folder in ['sources','runtime','prepared','exact_initial_audit','tests'] for p in sorted((ROOT/folder).rglob('*')) if p.is_file()}
    for p in sorted(ROOT.glob('*.py')):files[p.name]=sha(p)
    plan=dict(protocol='full-R1-OFF-fixed-original-integer-columns-two-representations-v1',
        basis_commits=['efcbb8e28d43fbebc830f21bc6648af282378370','bb3838d56f0771080e281840594841bb36cbe1a5'],
        frozen_files=files,source_freeze_sha256=sha(ROOT/'freeze.json'),
        representations=['original','equalities'],native_calls_per_representation=1,maximum_total_native_calls=2,retries=0,
        method_seconds_each=300.0,watchdog_seconds_each=380.0,matlab='F:/Matlab2023/Program_Files/MATLAB_R2023b/bin/matlab.exe',
        native_options=baseline,native_MaxTime=baseline['MaxTime'],
        mathematical_change='Only lb[j]=ub[j]=archived x0[j] for every original intcon column. Keep intcon, all continuous bounds, all rows, objective and x0 unchanged.',
        scientific_scope='Restricted continuous feasibility under one fixed integer assignment; original objective retained, not a zero-objective Phase-I model. No free integer schedule search, no R1 rebuild, no physical evaluation.',
        option_scope='Original efcbb8e OFF effective options including exact MaxTime retained. Same worker bytes and OutputFcn. Default iteration expressions unchanged; their evaluated row-count-dependent values differ between algebraic representations.',
        stop_rules=['No retry','Stop next representation on source drift, incomplete cleanup, missing exact integer fixation, unexpected nonzero branch nodes, or operational exception.',
                    'Continue once to second frozen representation on ordinary returned infeasibility or vector failure: this comparison is the diagnostic, not a formal performance pair.',
                    'If startup leaves less than native_MaxTime+5 seconds, do not solve; never shorten original native options silently.'],
        exact_offline_witness=dict(calls=1,algorithm='One saved-order pass over adjacent conditional affine opposite pairs; active binary gate=1, unique +1 continuous target set to exact rational midpoint. All original integer coordinates unchanged. Then exhaustive exact audit against BOTH frozen matrices. Failure stays unknown; no iterative repair.',
            use_as_native_x0=False,change_physical_parameters=False),
        native_vector_assessment='Every finite returned binary64 vector checked exactly against both original unfixed and fixed matrices; numerical tolerance alone is not a strict certificate.',
        conclusions='Exact all-row witness proves saved numerical feasibility only. -2 without exact infeasibility certificate remains solver-reported. No root-cause or general repair claim from a status change alone.')
    save(ROOT/'plan.json',plan);(ROOT/'plan.sha256').write_text(sha(ROOT/'plan.json')+'\n')
    print(json.dumps(dict(plan_sha256=sha(ROOT/'plan.json'),integer_columns=len(source[0]['intcon']),native_MaxTime=baseline['MaxTime'],frozen_files=len(files))))

def verify_plan():
    assert sha(ROOT/'plan.json')==(ROOT/'plan.sha256').read_text().strip()
    p=read(ROOT/'plan.json');verify_freeze()
    for name,h in p['frozen_files'].items():assert sha(ROOT/name)==h,name
    return p

def worker(label,start):
    plan=verify_plan();folder=ROOT/'runs'/label
    assert start==read(folder/'claim.json')['start_monotonic']
    from types import SimpleNamespace
    sys.path.insert(0,str(ROOT/'runtime'));import matlab_bridge as bridge
    budget=SimpleNamespace(deadline=start+plan['method_seconds_each'])
    bridge.REPO=folder/'isolated_preferences'
    p=payload(ROOT/'prepared'/(label+'.mat'));ix=p['intcon']
    assert np.array_equal(p['lb'][ix],p['ub'][ix]) and np.array_equal(p['lb'][ix],p['x0'][ix])
    assert np.equal(p['lb'][ix],np.floor(p['lb'][ix])).all()
    session=None;result=None;error=None;progress=[];seen=set();unexpected_branch=False
    try:
        session=bridge.MatlabSession(folder/'matlab',total_budget_s=budget.deadline-time.monotonic(),budget=budget,matlab_path=plan['matlab'])
        def poll(prefix):
            nonlocal unexpected_branch
            for path in sorted(folder.joinpath('matlab').glob('request_000001.event_*.json')):
                if path.name in seen:continue
                try:event=read(path)
                except (PermissionError,json.JSONDecodeError):continue
                seen.add(path.name);event['received_elapsed_s']=time.monotonic()-start
                progress.append({k:v for k,v in event.items() if k!='x'})
                if (event.get('values',{}).get('numnodes') or 0)>0:
                    unexpected_branch=True;Path(str(prefix)+'.cancel').touch()
        session.event_consumer=poll
        if budget.deadline-time.monotonic()<plan['native_MaxTime']+5:raise TimeoutError('Insufficient allowance to preserve original native MaxTime')
        result=session.solve(p,x0=p['x0'],budget=budget,remaining_s=budget.deadline-time.monotonic(),solver_max_time_s=plan['native_MaxTime'])
    except BaseException as exc:error=dict(type=type(exc).__name__,message=str(exc),traceback=traceback.format_exc())
    finally:
        stopped=time.monotonic()-start
        if session is not None:session.close()
    rawfile=folder/'matlab/request_000001.response.json'
    raw=read(rawfile) if rawfile.exists() else {}
    checks=dict(original_options_identical=raw.get('options')==plan['native_options'],
        all_original_integer_columns_exactly_fixed=True,no_integer_search=not unexpected_branch and (raw.get('output',{}).get('numnodes') or 0)==0,
        cleanup=bool(session and bridge.cleanup_is_complete(session.cleanup)),
        source_identity_after=all(sha(ROOT/name)==h for name,h in plan['frozen_files'].items()),
        no_exception=error is None)
    if session and session.counter:
        actual=payload(folder/'matlab/request_000001.mat')
        checks['actual_sent_arrays_match_frozen']=eq._digest(actual)==eq._digest(p)
    receipt=dict(representation=label,checks=checks,returned=result,raw_status=raw.get('status'),raw_exitflag=raw.get('exitflag'),
        error=error,progress=progress,native_calls=session.counter if session else 0,method_elapsed_s=stopped,total_elapsed_s=time.monotonic()-start,
        full_MILP_search=False,model_builds=0,thermal_evaluations=0,retries=0,
        mathematical_feasibility='UNKNOWN_PENDING_EXACT_VECTOR_AUDIT',
        continue_frozen_diagnostic=all(checks.values()))
    save(folder/'receipt.json',receipt)
    print(json.dumps({k:v for k,v in receipt.items() if k not in ['returned','progress']},ensure_ascii=False))

def run():
    p=verify_plan();runs=ROOT/'runs';runs.mkdir(exist_ok=False)
    completed=[]
    for label in p['representations']:
        verify_plan();folder=runs/label;folder.mkdir();start=time.monotonic()
        save(folder/'claim.json',dict(start_monotonic=start,once_only=True,plan_sha256=sha(ROOT/'plan.json')))
        temp=folder/'temp';temp.mkdir();env=dict(os.environ,TEMP=str(temp),TMP=str(temp),TMPDIR=str(temp))
        cmd=[sys.executable,'-B',str(Path(__file__).resolve()),'_worker','--label',label,'--start',repr(start)]
        save(folder/'command.json',dict(argv=cmd,cwd=str(ROOT),start_monotonic=start))
        with (folder/'stdout.log').open('x') as stdout,(folder/'stderr.log').open('x') as stderr:
            proc=subprocess.Popen(cmd,cwd=ROOT,env=env,stdout=stdout,stderr=stderr,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
            try:code=proc.wait(timeout=p['watchdog_seconds_each'])
            except subprocess.TimeoutExpired:
                import psutil
                process=psutil.Process(proc.pid);children=process.children(recursive=True)
                for child in children:child.kill()
                process.kill();gone,alive=psutil.wait_procs([process,*children],timeout=10)
                save(folder/'watchdog.json',dict(cleanup_complete=not alive,terminated_pids=[x.pid for x in gone]));code=-1
        save(folder/'controller.json',dict(returncode=code,wall_s=time.monotonic()-start))
        if code or not (folder/'receipt.json').exists():break
        receipt=read(folder/'receipt.json');completed.append(label)
        print((folder/'stdout.log').read_text(),flush=True)
        if not receipt['continue_frozen_diagnostic']:break
    save(runs/'summary.json',dict(completed=completed,omitted=[v for v in p['representations'] if v not in completed],
        retries=0,formal_performance_pair=False,scope='One pre-frozen fixed-integer continuous feasibility diagnostic.'))

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('command',choices=['prepare','run','_worker']);ap.add_argument('--label');ap.add_argument('--start',type=float);args=ap.parse_args()
    {'prepare':prepare,'run':run,'_worker':lambda:worker(args.label,args.start)}[args.command]()
