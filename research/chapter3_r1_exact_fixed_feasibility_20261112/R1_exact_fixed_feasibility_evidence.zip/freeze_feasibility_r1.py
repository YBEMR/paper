"""Freeze existing published OFF evidence without constructing any model."""
from pathlib import Path
import hashlib,json,shutil,subprocess,zipfile
r=Path(__file__).resolve().parent
out=r/'feasibility_r1'
out.mkdir(exist_ok=False)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
bindings={}
for commit,folder,archive in [
 ('efcbb8e28d43fbebc830f21bc6648af282378370','chapter3_native_pruning_pair_20261112','R1_native_pair_evidence.zip'),
 ('bb3838d56f0771080e281840594841bb36cbe1a5','chapter3_equality_pruning_pair_20261112','R1_equality_diagnostic_and_pair_evidence.zip')]:
    rel='research/'+folder+'/'+archive;p=r/'publish_repo'/rel
    expected=subprocess.check_output(['git','-C',str(r/'publish_repo'),'rev-parse',commit+':'+rel],text=True).strip()
    actual=subprocess.check_output(['git','-C',str(r/'publish_repo'),'hash-object',str(p)],text=True).strip()
    assert expected==actual
    bindings[commit]=dict(path=rel,git_blob=actual,archive_sha256=sha(p))
    with zipfile.ZipFile(p) as z:
        manifest=json.loads(z.read('MANIFEST_SHA256.json'))
        wanted=('execution/pair/off/method/' if commit.startswith('ef') else 'equality_pair_execution/pair/off/method/')
        label='original' if commit.startswith('ef') else 'equalities'
        for item in manifest['files']:
            name=item['path']
            if not name.startswith(wanted):continue
            value=z.read(name);assert hashlib.sha256(value).hexdigest()==item['sha256']
            target=out/'sources'/label/name[len(wanted):]
            target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(value)
for name in ['matlab_bridge.py','solve_model.m']:
    target=out/'runtime'/name;target.parent.mkdir(exist_ok=True)
    shutil.copyfile(r/'pair_source/research/chapter3_experiments'/name,target)
shutil.copyfile(r/'equality_pair_source/research/chapter3_experiments/numeric_case_diagnostic/exact_equalities.py',out/'runtime/exact_equalities.py')
inputs={p.relative_to(out).as_posix():sha(p) for p in sorted(out.rglob('*')) if p.is_file()}
f=dict(protocol='saved-full-auto-L-R1-OFF-exact-audit-v1',basis_commits=bindings,files=inputs,
    scope='Archived arrays and complete SAFE receipts only. No rebuild, solver, physics, new pruning or cache optimization.',
    row_identification='Saved sparse array row/column numbers; original payload has no semantic row tags. No reconstructed or inferred semantic names.',
    scientific_calls=0)
(out/'freeze.json').write_text(json.dumps(f,ensure_ascii=False,indent=2),encoding='utf-8')
(out/'freeze.sha256').write_text(sha(out/'freeze.json')+'\n',encoding='ascii')
print(json.dumps(dict(frozen_files=len(inputs),freeze_sha256=sha(out/'freeze.json')),ensure_ascii=False))
