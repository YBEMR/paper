"""Locate each strict x0 violation and row-scale flag without model reconstruction."""
from fractions import Fraction as Q
import csv,json,math
from exact_audit import ROOT,read,save,payload
out=ROOT/'row_locations';out.mkdir(exist_ok=False)
base=ROOT/'exact_initial_audit'
violations=[json.loads(s) for s in (base/'original/A_strict_violations.jsonl').read_text(encoding='utf-8').splitlines()]
new=[json.loads(s) for s in (base/'equalities/A_strict_violations.jsonl').read_text(encoding='utf-8').splitlines()]
cert=read(ROOT/'sources/equalities/matlab/request_000001.equality_certificate.json')
kept=[i for start,stop in cert['retained_le_row_ranges'] for i in range(start,stop)]
old_to_new={old:i for i,old in enumerate(kept)}
assert {(kept[v['row_zero_based']],v['residual_exact']) for v in new}=={(v['row_zero_based'],v['residual_exact']) for v in violations}
construction=read(ROOT/'rational_witness/construction.json')
pairmap={row:v for v in construction['active_pairs'] for row in [v['original_upper_row_zero_based'],v['original_lower_row_zero_based']]}
p=payload(ROOT/'sources/original/matlab/request_000001.mat');locations=[]
for v in violations:
    i=v['row_zero_based'];pair=pairmap.get(i)
    record=dict(original_row_0based=i,original_row_1based=i+1,equality_representation_inequality_row_0based=old_to_new[i],
        equality_representation_inequality_row_1based=old_to_new[i]+1,residual_exact=v['residual_exact'],residual_float=v['residual_float'],
        coefficients_and_point=v['terms'],belongs_to_active_conditional_affine_pair=pair is not None)
    if pair:
        width=Q(pair['upper_exact'])-Q(pair['lower_exact']);target=pair['target_column'];ulp=Q.from_float(math.ulp(float(p['x0'][target])))
        record.update(gate_column_0based=pair['gate_column'],target_column_0based=target,pair_upper_row_0based=pair['original_upper_row_zero_based'],
            pair_lower_row_0based=pair['original_lower_row_zero_based'],active_interval_width_exact=str(width),
            width_in_original_target_ulps=float(width/ulp),active_gate_value_exact=str(Q.from_float(float(p['x0'][pair['gate_column']]))))
    locations.append(record)
save(out/'all_97_strict_violations.json',locations)
with (out/'strict_violations.csv').open('x',encoding='utf-8',newline='') as f:
    keys=['original_row_1based','equality_representation_inequality_row_1based','residual_exact','residual_float','pair_upper_row_0based','gate_column_0based','target_column_0based','active_interval_width_exact','width_in_original_target_ulps']
    w=csv.DictWriter(f,fieldnames=keys,extrasaction='ignore');w.writeheader();w.writerows(locations)
scale=[];ratios=[];hidden=[];false_positive=[]
with (base/'original/A_all_rows.csv').open(encoding='utf-8',newline='') as f:
    for row in csv.DictReader(f):
        if 'coefficient_ratio_ge_1e9' in row['risk_flags']:
            scale.append(row);ratios.append(Q(row['coefficient_ratio']))
        exact=Q(row['residual_exact']);fl=float(row['residual_float64'])
        if exact>0 and fl<=0:hidden.append(int(row['row_zero_based']))
        if exact<=0 and fl>0:false_positive.append(int(row['row_zero_based']))
with (out/'scale_risk_rows.csv').open('x',encoding='utf-8',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(scale[0]));w.writeheader();w.writerows(scale)
summary=dict(strict_violation_count=len(locations),all_strict_violations_in_retained_inequalities=True,
    all_strict_violations_in_active_conditional_affine_pairs=all(v['belongs_to_active_conditional_affine_pair'] for v in locations),
    maximum_violation=max(locations,key=lambda v:Q(v['residual_exact'])),scale_risk_row_count=len(scale),maximum_row_coefficient_ratio=float(max(ratios)),
    hidden_positive_exact_residual_rows=hidden,float_false_positive_rows=false_positive,
    minimum_width_in_original_target_ulps=min(v['width_in_original_target_ulps'] for v in locations),
    row_tags_available=False,source_of_locations='Saved sparse matrices and exact row mapping only; no model build or inferred semantic tags.',
    interpretation='Strict tiny violations lie in active conditional affine row pairs; large coefficient ratios and roundoff effects are verified numerical risks, not proof of the internal MATLAB failure mechanism.')
save(out/'summary.json',summary)
print(json.dumps({k:v for k,v in summary.items() if k not in ['maximum_violation','hidden_positive_exact_residual_rows','float_false_positive_rows']},ensure_ascii=False,indent=2))
