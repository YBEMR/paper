"""Package reproducible evidence and separate verbose exact-row transcripts."""
from pathlib import Path
import hashlib,json,re,shutil,zipfile
ROOT=Path(__file__).resolve().parent
OUT=ROOT.parent.parent/'outputs'
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()
def write_zip(target,entries,metadata):
    manifest=dict(metadata,files=[dict(path=name,bytes=p.stat().st_size,sha256=sha(p)) for p,name in entries])
    with zipfile.ZipFile(target,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p,name in entries:z.write(p,name)
        z.writestr('MANIFEST_SHA256.json',json.dumps(manifest,ensure_ascii=False,indent=2))
    with zipfile.ZipFile(target) as z:
        for item in manifest['files']:
            h=hashlib.sha256()
            with z.open(item['path']) as f:
                for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
            assert h.hexdigest()==item['sha256'],item['path']
    return dict(archive=target.name,bytes=target.stat().st_size,sha256=sha(target),verified_files=len(entries),all_checksums_match=True)
assert json.loads((ROOT/'independent_verification.json').read_text(encoding='utf-8'))['passed']
large=[ROOT/'rational_witness'/label/'A_all_rows.csv' for label in ['original','equalities']]
for p in large:assert p.is_file()
large_entries=[(p,p.relative_to(ROOT).as_posix()) for p in large]
extended=write_zip(OUT/'R1有理数见证逐行扩展记录.zip',large_entries,dict(scope='Verbose exact residuals for every inequality of the rational witness; supplementary to independently verifiable matrices and full witness.'))
print(json.dumps(dict(extended=extended),ensure_ascii=False),flush=True)
with (ROOT/'extended_logs_receipt.json').open('x',encoding='utf-8') as f:json.dump(extended,f,ensure_ascii=False,indent=2)
report=OUT/'R1原生数值可行性诊断报告.txt'
with report.open('a',encoding='utf-8') as f:f.write('\n补充独立核验：另用整数乘法与二进制移位逐行验证同一有理数见证，未复用 Fraction 行求和或已存残差。两种表示全部通过；脚本 verify_witness.py，回执 independent_verification.json。无新求解、构模或物理调用。\n逐行有理数残差的两份超长成功日志单独打包为 R1有理数见证逐行扩展记录.zip；主证据包保留原矩阵、完整见证、全部严格违反及尺度定位、两种独立检查器、摘要和扩展包校验，足以独立复核严格结论。\n')
shutil.copyfile(ROOT/'row_locations/strict_violations.csv',OUT/'R1严格违反行定位.csv')
entries=[];excluded=[]
for p in sorted(ROOT.rglob('*')):
    if not p.is_file():continue
    rel=p.relative_to(ROOT)
    if any(part in ['isolated_preferences','.runtime','temp','test_temp','__pycache__'] for part in rel.parts):
        excluded.append(dict(path=rel.as_posix(),reason='non-scientific runtime preferences or temporary files'));continue
    if p in large:
        excluded.append(dict(path=rel.as_posix(),reason='included in separate extended log archive',sha256=sha(p),bytes=p.stat().st_size));continue
    assert p.suffix.lower() not in ['.pem','.p12']
    entries.append((p,rel.as_posix()))
entries.extend([(report,report.name),(ROOT.parent/'freeze_feasibility_r1.py','freeze_feasibility_r1.py')])
pattern=re.compile(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----|gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{50,}')
for p,name in entries:
    if p.suffix.lower() in ['.py','.json','.log','.txt','.m']:
        assert not pattern.search(p.read_bytes()),name
receipt=write_zip(OUT/'R1数值可行性诊断证据.zip',entries,dict(excluded=excluded,extended_logs=extended,
    source_commits=['efcbb8e28d43fbebc830f21bc6648af282378370','bb3838d56f0771080e281840594841bb36cbe1a5'],credential_pattern_scan='clear'))
receipt['extended_logs']=extended
with (OUT/'R1数值诊断交付校验.json').open('x',encoding='utf-8') as f:json.dump(receipt,f,ensure_ascii=False,indent=2)
print(json.dumps(receipt,ensure_ascii=False),flush=True)
