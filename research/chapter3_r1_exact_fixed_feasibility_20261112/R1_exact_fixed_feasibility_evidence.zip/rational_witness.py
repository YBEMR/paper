"""Single predeclared exact continuous witness construction, never sent to MATLAB."""
from fractions import Fraction as Q
import json,time
import numpy as np
from exact_audit import ROOT,read,save,payload,audit,sha
from fixed_diagnostic import verify_plan
def main():
    plan=verify_plan();out=ROOT/'rational_witness';out.mkdir(exist_ok=False)
    p=payload(ROOT/'prepared/original.mat');a=p['A'].tocsr();b=p['b'];x=[Q.from_float(float(v)) for v in p['x0']];old=list(x)
    ints=set(map(int,p['intcon']));active=[];allpairs=[];start=time.monotonic();error=None
    q=lambda v:Q.from_float(float(v))
    try:
        for i in range(a.shape[0]-1):
            if time.monotonic()-start>180:raise TimeoutError('Single offline witness construction limit')
            sl=slice(a.indptr[i],a.indptr[i+1]);sr=slice(a.indptr[i+1],a.indptr[i+2]);ix=a.indices[sl];jx=a.indices[sr];av=a.data[sl];bv=a.data[sr]
            if not np.array_equal(ix,jx):continue
            sums=[q(v)+q(w) for v,w in zip(av,bv)];nz=[k for k,v in enumerate(sums) if v]
            if len(nz)!=1 or sums[nz[0]]<=0:continue
            k=nz[0];gate=int(ix[k])
            if not (p['lb'][gate] in (0,1) and p['ub'][gate] in (0,1) and x[gate] in (0,1)):continue
            width=q(b[i])+q(b[i+1])-q(av[k])-q(bv[k])
            if width<0:raise ValueError('Negative exact affine interval width at '+str(i))
            allpairs.append(i)
            if x[gate]!=1:continue
            targets=[int(j) for j,v in zip(ix,av) if v==1 and j!=gate]
            if len(targets)!=1:raise ValueError('Nonunique target at '+str(i))
            target=targets[0]
            if target in ints:raise ValueError('Integer target forbidden')
            if bv[np.flatnonzero(jx==target)[0]]!=-1:raise ValueError('Wrong opposite target')
            upper=q(b[i])-sum((q(v)*x[int(j)] for j,v in zip(ix,av) if j!=target),Q(0))
            lower=sum((q(v)*x[int(j)] for j,v in zip(jx,bv) if j!=target),Q(0))-q(b[i+1])
            if lower>upper:raise ValueError('Empty active exact interval at '+str(i))
            x[target]=(lower+upper)/2
            active.append(dict(original_upper_row_zero_based=i,original_lower_row_zero_based=i+1,gate_column=gate,target_column=target,lower_exact=str(lower),upper_exact=str(upper),target_exact=str(x[target])))
        if len({v['target_column'] for v in active})!=len(active):raise ValueError('Target reused; no iterative repair allowed')
        assert all(x[i]==old[i] for i in ints)
    except Exception as exc:error=dict(type=type(exc).__name__,message=str(exc))
    with (out/'witness_fraction_lines.txt').open('x',encoding='ascii',newline='\n') as f:
        for v in x:f.write(str(v)+'\n')
    save(out/'construction.json',dict(error=error,all_affine_pairs=len(allpairs),active_pairs=active,
        changed_columns=[i for i,(v,w) in enumerate(zip(x,old)) if v!=w],integer_columns_unchanged=all(x[i]==old[i] for i in ints),
        maximum_change_float=max(float(abs(v-w)) for v,w in zip(x,old)),elapsed_s=time.monotonic()-start,
        witness_sha256=sha(out/'witness_fraction_lines.txt'),native_x0_unchanged=True))
    results={}
    for label in ['original','equalities']:
        results[label]=audit(payload(ROOT/'prepared'/(label+'.mat')),x,out/label,'rational_witness_fixed_'+label)
    save(out/'result.json',dict(exact_fixed_subproblem_feasible=error is None and all(v['exact_feasible'] for v in results.values()),
        construction_error=error,results=results,solver_calls=0,model_builds=0,thermal_evaluations=0,
        scope='Strict feasibility of the frozen binary64 numerical rows with archived integer assignment. Rational vector is not necessarily binary64 representable, is not sent as x0, and is not an additional physical SAFE result.'))
    verify_plan();print(json.dumps(dict(exact_feasible=error is None and all(v['exact_feasible'] for v in results.values()),error=error),ensure_ascii=False))
if __name__=='__main__':main()
