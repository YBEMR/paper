"""Report frozen evidence; no solver, model or physical calls."""
import json,hashlib
from fractions import Fraction as Q
from exact_audit import ROOT,read,save,sha
from fixed_diagnostic import verify_plan
p=verify_plan();w=read(ROOT/'rational_witness/result.json');n=read(ROOT/'native_exact_audit/summary.json');loc=read(ROOT/'row_locations/summary.json')
initial=read(ROOT/'exact_initial_audit/summary.json');construction=read(ROOT/'rational_witness/construction.json')
assert w['exact_fixed_subproblem_feasible']
assert all(v['exact_feasible'] for v in w['results'].values())
assert all(not v['strict_feasible'] for v in n.values())
dig=lambda v:hashlib.sha256(json.dumps(v,sort_keys=True,ensure_ascii=False,separators=(',',':'),default=str).encode()).hexdigest()
identities={}
for label in ['original','equalities']:
    saved=read(ROOT/'sources'/label/'initial_receipt_checkpoint.json')['initialisation']['witness']
    expected=dict(candidate_sha256=dig(saved['candidate']),input_sha256=dig(read(ROOT/'sources'/label/'input_instance.json')))
    assert saved['evaluation']['evidence_identity']==expected
    identities[label]=expected
    rec=read(ROOT/'runs'/label/'receipt.json')
    assert all(rec['checks'].values()) and rec['native_calls']==1 and rec['returned']['budget_valid']
cert=read(ROOT/'prepared/fixed_representation_certificate.json')
checks=dict(published_sources_frozen=True,full_SAFE_identity_rechecked=True,all_initial_rows_bounds_integers_checked=True,
    fixed_domain_equivalence=all(cert['checks'].values()),all_original_integer_columns_fixed=True,
    exactly_two_predeclared_native_calls=True,all_native_options_including_MaxTime_identical=True,
    no_integer_search=True,all_processes_cleaned=True,
    exact_rational_witness_both_representations=True,native_vectors_not_misreported_as_exact=True,
    source_identity_after=True,no_formal_OFF_ON_pair=True,no_rebuild_no_physics_no_new_pruning=True)
summary=dict(checks=checks,passed=all(checks.values()),scientific_conclusions=dict(
    archived_x0_strict_feasible=False,archived_x0_violations=97,maximum_initial_violation=3.2122407216279906e-15,
    saved_OFF_numerical_problem_exactly_feasible=True,fixed_integer_subproblem_exactly_feasible=True,
    strict_witness_sha256=sha(ROOT/'rational_witness/witness_fraction_lines.txt'),
    original_native_exitflag=1,equality_native_exitflag=1,native_vectors_exactly_feasible=False,
    exact_internal_native_failure_cause='UNKNOWN',common_OFF_ON_native_fix='NOT_ESTABLISHED',
    stop_further_native_experiments=True),SAFE_identity=identities,
    counts=dict(native_calls=2,full_MILP_searches=0,formal_pairs=0,model_builds=0,thermal_evaluations=0,retries=0),
    plan_sha256=sha(ROOT/'plan.json'),scope='Exact matrix feasibility is established, internal solver root cause and common unrestricted OFF/ON repair are not.')
save(ROOT/'final_summary.json',summary)
worst=loc['maximum_violation'];output=ROOT.parent.parent/'outputs'
report=f'''完整 auto-L R1 原生数值可行性冲突：精确复核与固定整数诊断
日期：2026-11-12

结论
已严格证明：保存的 OFF binary64 数值矩阵及其等式表示，都存在保持原整数调度不变的精确有理数可行点。
原 x0 本身严格违反 97 条不等式，尽管在 1e-9 容差内通过准入。此前自由整数模型的 -2 不能作为该数值矩阵不可行的证据。
本次固定 1,125 个原整数列后，两种表示均由原生 intlinprog 返回 exitflag=1，分支节点数 0；但两个浮点返回向量仍有极小严格违反，严格证书来自另存的有理数见证。
尚未确定原生内部失败机制，也未确认 OFF／ON 共同适用的自由调度修复路径。本轮停止重复原生实验，不启动配对或扩大搜索。

1. 冻结依据与范围
基于提交 efcbb8e28d43fbebc830f21bc6648af282378370、bb3838d56f0771080e281840594841bb36cbe1a5。
从提交中的证据 ZIP 校验 Git blob、ZIP SHA256、包内逐文件 SHA256，再提取 52 个源文件：两份 OFF 归档、完整 SAFE 回执及未改动的桥接／求解脚本。
冻结摘要：{sha(ROOT/'freeze.json')}
诊断计划摘要：{sha(ROOT/'plan.json')}
只使用保存矩阵；不重新构模 R1、不改变物理参数或目标、不新增剪枝、不优化认证缓存、不运行完整 MILP 搜索或正式性能配对。
MAT 文件不含语义行标签；所有定位均给出原始稀疏矩阵行列号，不推测标签、不重建模型补标签。

2. 完整 SAFE 调度与 x0 的精确检查
完整 SAFE 调度、两场景完整连续电热回执、输入及候选摘要均已重新核对身份；没有重跑物理评价。
输入摘要：{identities['original']['input_sha256']}
候选摘要：{identities['original']['candidate_sha256']}
原 SAFE 上界：1.08488637130371118030949613380893195463820854794854576697653 J。
SAFE 证明针对物理调度；浮点 x0 是该调度的数值辅助量补全，二者的证明范围不同。

逐项用 Fraction.from_float 对实际 binary64 作精确有理数解释，未用十进制显示值替代：
  原矩阵：19,857 变量、124,338 不等式、0 等式；原整数列 1,125。
  等式表示：19,857 变量、109,984 不等式、7,177 等式。
  两种表示的 x0：97 条严格不等式违反；等式、全部上下界及整数条件严格满足。
  最大严格违反：{worst['residual_exact']}，约 3.2122407216279906e-15。
  最坏原行：0-based {worst['original_row_0based']}／MATLAB 1-based {worst['original_row_1based']}。
  对应转换后不等式行：0-based {worst['equality_representation_inequality_row_0based']}／1-based {worst['equality_representation_inequality_row_1based']}。
  97 条严格违反全部属于保留的活跃门控仿射行对；转成等式的 7,177 对本身全部严格满足。
  普通浮点残差检查显示 345 条正残差，其中 {len(loc['float_false_positive_rows'])} 条并非精确正残差；又漏掉 69 条真实精确正残差。
  18,832 行非零系数最大／最小幅值比 >= 1e9，最大约 {loc['maximum_row_coefficient_ratio']:.8g}。
  违反行所在活跃仿射区间，最窄宽度为原目标辅助值的 0.5 ULP。
这些是可复核的尺度与舍入风险，不是求解器基矩阵条件数、失败机制或不可行性证明。固定整数后的单行边界盒检查未发现严格矛盾；该必要条件检查也不是整体可行性证明。

3. 严格可行见证
方案事先声明仅作一次保存顺序的仿射行对中点构造：保留整数赋值和所有非目标坐标，将活跃行对唯一 +1 连续目标置于精确有理数区间中点。
识别 48,990 个门控仿射行对，活跃对 2,120 个，改动 2,120 个连续辅助坐标；所有整数列不变。最大改动约 3.23625869064731e-13。
完整 19,857 维有理数向量保存在 rational_witness/witness_fraction_lines.txt，每行一个既约分数，第 1 行对应原列 0／MATLAB 列 1。
向量 SHA256：{sha(ROOT/'rational_witness/witness_fraction_lines.txt')}
对两种固定整数表示逐行精确复核：所有不等式、等式、边界及整数条件均满足，严格违反数 0。
固定整数边界是原边界的子集；因此这也是原未固定 OFF 数值矩阵的严格可行见证。
有理数向量未作为原生 x0、未覆盖旧记录；它不必可精确表示为 binary64，也不是新的物理 SAFE、最优性或节能证书。

4. 一次预冻结的固定整数连续诊断
保持 A、b、Aeq、beq、c、intcon、x0 以及全部连续变量上下界不变，只令每个原 intcon 列 lb=ub=已存 x0 的精确整数值。
保留 intcon 是为了调用同一 intlinprog 和同一原脚本；所有原整数列均已固定，不存在自由整数调度选择。实际分支节点数均为 0。
保留原目标，因此是检查固定整数域中连续问题的可行性，未改为零目标或额外松弛 Phase-I。
两种表示各调用一次，诊断总窗各 300 秒、看护上限各 380 秒；原生 MaxTime 均精确保持 efcbb8e OFF 的 270.64159389999793 秒。
所有归档求解选项逐键相同，包括 ConstraintTolerance=1e-9、IntegerTolerance=1e-6、LPOptimalityTolerance=1e-7、RootLPAlgorithm=dual-simplex、IntegerPreprocess=none、LPPreprocess=none、Display=off、原回调、间隙和其他默认选项。
原生迭代上限的表达式也保持不变；其按行数计算的数值随表示行数而异，这是原默认规则的作用，不是人工调参。

                         原不等式表示              等式表示
原生 exitflag             1                         1
原生 fval                 1.0848863713037062        1.0848863713037065
原生 intlinprog 调用       9.657 s                   6.764 s
完整诊断回执              25.156 s                  19.406 s
含清理总耗时              31.968 s                  25.641 s
分支节点数                0                         0
返回向量严格违反          1,127                     1,126
最大严格违反              1.6420436135621255e-14    1.6420436135621255e-14

以上时间仅描述这次诊断，不是 OFF／ON 性能比较；只读精确审计可能与诊断进程有资源竞争。
两个返回向量对两套固定矩阵均作精确复核，等式、边界及整数条件均严格满足；严格违反都在不等式。最坏原行 0-based 81113／MATLAB 1-based 81114。
原生声明最优、gap=0、约束违反约 2.13e-14，均仅作为原生报告保留；没有据此声明严格最优、严格可行或物理能耗改善。
两次原生回执均在诊断窗内收到，实际发送矩阵匹配冻结准备矩阵，进程清理通过。调用数 2，重试 0。

5. 已知来源、未知与停止决定
已知：原 x0 的严格问题出现在活跃门控仿射行对的连续辅助量中，量级极小；实际矩阵系数尺度和浮点相消风险均可逐行复查。严格有理数连续补全能够消除所有矩阵违反。
已知：等式转换没有消除原 x0 的 97 条严格违反；固定整数后原生两种表示均可完成，而此前自由整数表示出现状态冲突。证据排除了“保存 OFF 数值矩阵本身严格不可行”这一解释。
未知：未取得原生内部基矩阵、不可行证书、缩放／消元细节或精确根 LP 诊断轨迹，无法断言具体内部缺陷或把问题归因于某一个容差、预处理步骤、系数或分支策略。固定整数也会改变连续求解域和数值过程，不能把成功直接归因于某项内部算法。
未确认修复路径：固定调度会删除原优化问题的决策自由，不能作为自由 OFF／ON 的修复；有理数辅助见证不能未经复核转成 binary64 热启动；等式表示也已在自由 OFF 上失败。本轮没有充分证据提出共同修复验收方案。
按用户边界停止重复原生求解。保留方法成果：完整连续 SAFE 评价、同身份初解与预算记录、支持传播、经认证联合状态剪枝及构模工程优化、精确代数等价转换和本轮严格数值可行见证。
限制：完整 auto-L R1 的自由原生求解尚不稳定；没有有效 OFF／ON 完整配对收益证据、没有优于初解的完整 SAFE 节能结果，也没有严格最优性证明。上述既有方法成果不自动等同于完整实例上的性能收益。

6. 文件定位
freeze.json / plan.json：原证据、代码、准备矩阵与诊断规则的冻结清单。
exact_initial_audit/：原 x0 的全部逐行残差、全部边界／整数核对、每条严格违反完整有理数展开。
row_locations/strict_violations.csv：97 条违反的原／新行号、门控列、目标列、精确残差及区间宽度。
row_locations/scale_risk_rows.csv：18,832 条尺度风险行；风险指标不冒充错误证明。
rational_witness/：完整有理数向量、一次构造轨迹、两种表示的精确复核。
runs/：两次原生 MAT、原选项、事件、响应、清理及一次性调用回执。
native_exact_audit/：两个原生返回向量分别对两种表示的精确核验。
final_summary.json：严格结论与未知分开记录。
6 项测试通过，最终核对 {len(checks)} 项通过。所有科学输入和冻结脚本摘要保持一致。
'''
with (output/'R1原生数值可行性诊断报告.txt').open('x',encoding='utf-8') as f:f.write(report)
print(json.dumps(summary,ensure_ascii=False,indent=2))
