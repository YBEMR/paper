import tempfile,unittest,json
from pathlib import Path
from fractions import Fraction as Q
import numpy as np
from scipy import sparse
from exact_audit import audit,ROOT,payload,eq
from fixed_diagnostic import fixed
def fixture():
    return dict(c=np.zeros(3),A=sparse.csc_matrix([[1e16,1.,-1e16]]),b=np.zeros(1),Aeq=sparse.csc_matrix((0,3)),beq=np.zeros(0),lb=np.zeros(3),ub=np.full(3,2.),intcon=np.array([0],dtype=np.int64),x0=np.ones(3))
class Tests(unittest.TestCase):
    def test_exact_hidden_violation(self):
        with tempfile.TemporaryDirectory(dir=ROOT/'test_temp') as td:
            r=audit(fixture(),np.ones(3),Path(td)/'audit','fixture')
            self.assertFalse(r['exact_feasible']);self.assertEqual(r['rows']['A']['maximum_violation_exact'],'1')
            self.assertEqual(r['rows']['A']['exact_violations_hidden_by_float'],1)
    def test_bounds_and_integrality(self):
        p=fixture();p['x0'][0]=.5;p['x0'][1]=3.
        with tempfile.TemporaryDirectory(dir=ROOT/'test_temp') as td:
            r=audit(p,p['x0'],Path(td)/'audit','fixture')
            self.assertEqual(r['integer_violating_columns'],[0]);self.assertEqual(r['bound_violating_columns'],[1])
    def test_exact_rational_equality(self):
        p=fixture();p['A']=sparse.csc_matrix((0,3));p['b']=np.zeros(0);p['Aeq']=sparse.csc_matrix([[0.,3.,0.]]);p['beq']=np.array([1.])
        with tempfile.TemporaryDirectory(dir=ROOT/'test_temp') as td:
            r=audit(p,[Q(1),Q(1,3),Q(1)],Path(td)/'audit','fixture')
            self.assertTrue(r['exact_feasible'])
    def test_fixed_only_integer_bounds(self):
        p=fixture();d=fixed(p)
        self.assertEqual(d['lb'][0],1.);self.assertEqual(d['ub'][0],1.)
        self.assertEqual(p['lb'][0],0.);self.assertEqual(p['ub'][0],2.)
        self.assertEqual(eq._digest(p)['A'],eq._digest(d)['A'])
    def test_noninteger_fix_rejected(self):
        p=fixture();p['x0'][0]=.5
        with self.assertRaises(AssertionError):fixed(p)
    def test_real_original_and_equality_identity(self):
        p=payload(ROOT/'sources/original/matlab/request_000001.mat');d=payload(ROOT/'sources/equalities/matlab/request_000001.mat')
        a=fixed(p);b=fixed(d)
        self.assertEqual(len(a['intcon']),1125)
        self.assertTrue(np.array_equal(a['lb'],b['lb']));self.assertTrue(np.array_equal(a['ub'],b['ub']))
        self.assertEqual(eq._digest(a)['x0'],eq._digest(b)['x0'])
if __name__=='__main__':
    (ROOT/'test_temp').mkdir(exist_ok=True);(ROOT/'tests').mkdir(exist_ok=False)
    with (ROOT/'tests/unittest.log').open('x',encoding='utf-8') as f:r=unittest.TextTestRunner(stream=f,verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Tests))
    (ROOT/'tests/result.json').write_text(json.dumps(dict(tests=r.testsRun,passed=r.wasSuccessful(),failures=len(r.failures),errors=len(r.errors),native_calls=0)),encoding='utf-8')
    print((ROOT/'tests/unittest.log').read_text());raise SystemExit(not r.wasSuccessful())
