"""Once-only original R2023b pair. Default/verify/freeze never solve.

probe starts and closes MATLAB without a solve. Only run --execute launches
the two method workers. Each worker's 300 seconds starts before Popen.
"""
import time
ENTRY_MONOTONIC = time.monotonic()
import argparse
from datetime import datetime, timezone
from functools import partial
import hashlib
from importlib import metadata
import json
import math
import os
from pathlib import Path, PurePosixPath
import platform
import subprocess
import sys
import traceback

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
LIMIT = 300.0
ARMS = ('off', 'on')
SCHEMA = 'pruned-native-equality-pair-v1'


def utc(): return datetime.now(timezone.utc).isoformat()
def read(path): return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
        separators=(',', ':'), default=str).encode()).hexdigest()
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def save(path, value):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x', encoding='utf-8') as f:
        json.dump(value, f, ensure_ascii=False, indent=2, allow_nan=False)
def event(folder, kind, **fields):
    with (Path(folder)/'events.jsonl').open('a', encoding='utf-8') as f:
        f.write(json.dumps(dict(utc=utc(), event=kind, **fields), ensure_ascii=False)+'\n')


def safe_path(root, name):
    q = PurePosixPath(name)
    if not isinstance(name, str) or q.is_absolute() or ':' in name or '\\' in name or '..' in q.parts:
        raise ValueError('UNSAFE_MANIFEST_PATH')
    p = root.joinpath(*q.parts)
    if not p.resolve().is_relative_to(root.resolve()): raise ValueError('PATH_ESCAPE')
    for a in [p, *p.parents]:
        if a == root: break
        if a.is_symlink() or getattr(a, 'is_junction', lambda: False)(): raise ValueError('LINK_PATH')
    return p


def verify(root=ROOT, check=lambda: None):
    m = read(root/'bundle_manifest.json')
    if m['schema'] != SCHEMA or m['seconds'] != LIMIT or m['arms'] != list(ARMS):
        raise ValueError('BUNDLE_SCOPE_DRIFT')
    for name, expected in m['files'].items():
        check()
        if sha(safe_path(root, name)) != expected: raise ValueError('SOURCE_DRIFT:'+name)
    check()
    gate = read(safe_path(root, m['diagnostic_gate_file']))
    if not (gate.get('passed') is True and gate.get('checks') and all(gate['checks'].values())
            and gate.get('native_calls') == 1 and gate.get('retries') == 0):
        raise ValueError('EQUALITY_DIAGNOSTIC_NOT_PASSED')
    return m


def environment():
    return dict(host=platform.node(), system=platform.system(), python=sys.version,
        executable=str(Path(sys.executable).resolve()),
        machine=platform.machine(),os_release=platform.release(),logical_cpus=os.cpu_count(),
        thread_environment={k:os.environ.get(k) for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS']},
        packages={n:metadata.version(n) for n in ['numpy','scipy','psutil']})


def flags(manifest, arm):
    if arm not in ARMS: raise ValueError('UNKNOWN_ARM')
    base = dict(manifest['baseline_flags'])
    if 'propagate_support' in base or 'prune_joint_states' in base: raise ValueError('DUPLICATE_SWITCH')
    return dict(base, propagate_support=True, prune_joint_states=arm == 'on')


def timely(value):
    return type(value) in (int,float) and math.isfinite(value) and 0 <= value < LIMIT


def validate_seed(initial, input_hash, expected=None):
    if initial.get('state') != 'SAFE_POINT_READY': raise ValueError('SEED_NOT_READY')
    w = initial.get('witness') or {}; ev = w.get('evaluation') or {}
    candidate = w.get('candidate'); h = digest(candidate)
    comp = initial.get('completion') or {}; admission = comp.get('numerical_acceptance') or {}
    if candidate is None or (expected is not None and h != expected): raise ValueError('COMMON_SEED_MISMATCH')
    if ev.get('evidence_identity') != dict(input_sha256=input_hash,candidate_sha256=h): raise ValueError('SEED_RECEIPT_IDENTITY')
    if (ev.get('state') != 'SAFE' or ev.get('rankable_energy') is not True
        or ev.get('safe_upper_bound_J') is None or not timely(ev.get('completed_at_elapsed_s'))):
        raise ValueError('SEED_NOT_TIMELY_SAFE')
    if (comp.get('state') != 'INITIAL_POINT_READY' or comp.get('decoded_roundtrip') is not True
        or admission.get('accepted_numerically') is not True or not timely(comp.get('completed_at_s'))):
        raise ValueError('SEED_X0_NOT_TIMELY_ADMITTED')
    return dict(candidate_sha256=h, input_sha256=input_hash,
        safe_upper_bound_J=ev['safe_upper_bound_J'], safe_completed_s=ev['completed_at_elapsed_s'],
        x0_completed_s=comp['completed_at_s'])


class Guard:
    def __init__(self, session, checkpoint, input_hash, expected, decoder, admit, folder):
        self.session=session; self.checkpoint=checkpoint; self.input_hash=input_hash
        self.expected=expected; self.decoder=decoder; self.admit=admit; self.folder=folder
        self.record={'status':'NOT_REACHED'}
    def __getattr__(self, name): return getattr(self.session,name)
    @property
    def event_consumer(self): return self.session.event_consumer
    @event_consumer.setter
    def event_consumer(self, value): self.session.event_consumer=value
    def solve(self, model, *, budget, x0=None, **kwargs):
        budget.check()
        if self.record['status']=='REJECTED': raise ValueError('SEED_GUARD_PREVIOUSLY_REJECTED')
        if self.record['status']=='NOT_REACHED':
            try:
                with budget.phase('pair_seed_identity_and_x0_guard'):
                    facts=validate_seed(read(self.checkpoint)['initialisation'],self.input_hash,self.expected)
                    if max(facts['safe_completed_s'],facts['x0_completed_s']) > budget.elapsed:
                        raise ValueError('SEED_RECEIPT_FROM_FUTURE')
                    if x0 is None or digest(self.decoder(x0)) != facts['candidate_sha256']:
                        raise ValueError('ACTUAL_X0_IDENTITY')
                    admitted=self.admit(model,x0=x0)
                    if admitted.get('x0_validation',{}).get('accepted_numerically') is not True:
                        raise ValueError('ACTUAL_X0_RESIDUAL_REJECTED')
                    budget.check()
                    self.record=dict(status='PASSED',**facts,guard_completed_s=budget.elapsed,
                        actual_vector_length=len(x0), actual_x0_admission=admitted['x0_validation'])
                    save(self.folder/'seed_guard.json',self.record)
            except BaseException as e:
                self.record=dict(status='REJECTED',reason=type(e).__name__+': '+str(e),completed_s=budget.elapsed)
                if not (self.folder/'seed_guard.json').exists():save(self.folder/'seed_guard.json',self.record)
                raise
        budget.check()
        return self.session.solve(model,budget=budget,x0=x0,**kwargs)


def accepted_summary(result):
    """Archive existing receipts only; never evaluate a candidate here."""
    ev=result.get('evaluation') or {}
    safe=(result.get('state')=='SAFE' and ev.get('state')=='SAFE'
        and ev.get('rankable_energy') is True and timely(ev.get('completed_at_elapsed_s'))
        and ev.get('safe_upper_bound_J') is not None and result.get('safe_candidate') is not None)
    initial=((result.get('initialisation') or {}).get('witness') or {}).get('candidate')
    candidate=result.get('safe_candidate') if safe else None
    diagnostic=result.get('diagnostic') or {}
    candidates=[]
    for row in diagnostic.get('evaluations',[]):
        c=row.get('candidate');e=row.get('evaluation') or {}
        candidates.append(dict(source=row.get('source'),candidate_sha256=digest(c) if c is not None else None,
            equals_initial=digest(c)==digest(initial) if c is not None and initial is not None else None,
            received_or_returned_s=row.get('evaluation_returned_at_s'),
            SAFE_completed_s=e.get('completed_at_elapsed_s'),accepted_safe=row.get('accepted_safe'),
            state=e.get('state'),safe_upper_bound_J=e.get('safe_upper_bound_J')))
    return dict(accepted_in_budget_safe=bool(safe),
        candidate_sha256=digest(candidate) if candidate is not None else None,
        safe_upper_bound_J=ev.get('safe_upper_bound_J') if safe else None,
        safe_completed_s=ev.get('completed_at_elapsed_s') if safe else None,
        equals_initial=(digest(candidate)==digest(initial)) if candidate is not None and initial is not None else None,
        solver_improvement_claimed=False,
        reason=result.get('reason'), solver_entered=result.get('integer_solver_entered'),
        native_returns=[{k:v for k,v in rr.items() if k not in ('x','callbacks')}
                        for rr in result.get('rounds',[])],
        candidate_receipts=candidates,solver_progress=diagnostic.get('solver_progress',[]),
        root_lp_objective=None,root_lp_status='Not inferred; inspect original native log if reported',
        bounds_scope='Original callback/return solver reports; no independent lower-bound certification',
        root_lp='See original MATLAB logs/events; unavailable fields remain missing, never fabricated')


def anchor_budget(start, clock=time.monotonic):
    from timing import MethodBudget
    if not math.isfinite(start) or start > clock(): raise ValueError('INVALID_PARENT_CLOCK')
    b=MethodBudget(LIMIT,clock=clock);b.start=start;b.deadline=start+LIMIT
    return b


def memory_observation():
    import psutil
    v=psutil.virtual_memory();p=psutil.Process()
    return dict(utc=utc(),physical_total_bytes=v.total,physical_available_bytes=v.available,
        python_rss_bytes=p.memory_info().rss,
        scope='Point observation, not a promise of native peak memory or exclusive machine access')


def isolated_session(workdir, **kwargs):
    """Original bridge, isolated preferences. Single-thread construction only.

    In frozen matlab_bridge.py REPO is used only to choose MATLAB_PREFDIR.
    Scope the relocation to constructor execution and restore even on failure;
    HERE (solver sources), numerical options and every solver operation stay intact.
    """
    import matlab_bridge
    previous=matlab_bridge.REPO
    matlab_bridge.REPO=Path(workdir).resolve().parent/'isolated_matlab_preferences'
    try:return matlab_bridge.MatlabSession(workdir,**kwargs)
    finally:matlab_bridge.REPO=previous


def represented_session(session):
    from numeric_case_diagnostic.equality_session import attach
    try:
        return attach(session)
    except BaseException as error:
        session.close()
        error.matlab_cleanup = session.cleanup
        raise


def probe(matlab, output):
    """Future Windows readiness check only. No intlinprog solve request."""
    verify(); out=Path(output).resolve();out.mkdir(parents=True,exist_ok=False)
    sys.path.insert(0,str(ROOT/'research/chapter3_experiments'))
    from matlab_bridge import MatlabSession, cleanup_is_complete
    from timing import MethodBudget
    b=MethodBudget(90); session=None;ready=None;failure=None;cleanup=None
    try:
        session=isolated_session(out/'matlab',matlab_path=Path(matlab).resolve(),budget=b,total_budget_s=b.remaining)
        ready=session.environment
    except BaseException as e:
        failure=dict(type=type(e).__name__,message=str(e))
        cleanup=getattr(e,'matlab_cleanup',None)
    finally:
        if session is not None:
            session.close();cleanup=session.cleanup
    record=dict(created_utc=utc(),environment=environment(),matlab=str(Path(matlab).resolve()),
        matlab_sha256=sha(matlab) if Path(matlab).is_file() else None,ready=ready or {},cleanup=cleanup,
        cleanup_complete=cleanup_is_complete(cleanup),failure=failure,solver_calls=0,
        manifest_sha256=sha(ROOT/'bundle_manifest.json'),memory=memory_observation(),
        scope='Startup/license probe only; no MILP or thermal validation')
    save(out/'environment_receipt.json',record)
    return record


def freeze(probe_file, plan_file):
    m=verify();r=read(probe_file)
    age=(datetime.now(timezone.utc)-datetime.fromisoformat(r['created_utc'])).total_seconds()
    if not 0 <= age <= 86400 or r['environment'] != environment() or platform.system()!='Windows':
        raise ValueError('CURRENT_WINDOWS_PROBE_REQUIRED')
    if (r.get('failure') or r['ready'].get('release')!='2023b' or r['ready'].get('license_checkout') is not True
        or not r['ready'].get('intlinprog_path') or not r['cleanup_complete']
        or r['manifest_sha256']!=sha(ROOT/'bundle_manifest.json') or sha(r['matlab'])!=r['matlab_sha256']):
        raise ValueError('PROBE_NOT_ACCEPTED')
    plan=dict(schema=SCHEMA,created_utc=utc(),root=str(ROOT),manifest_sha256=sha(ROOT/'bundle_manifest.json'),
        environment=environment(),matlab=r['matlab'],matlab_sha256=r['matlab_sha256'],
        probe_file=str(Path(probe_file).resolve()),probe_sha256=sha(probe_file),
        seconds=LIMIT,arms=list(ARMS),watchdog_s=380,
        seed_policy='Original deterministic-initial-schedule-v1, max3, fresh complete SAFE and x0 each arm; identity-only OFF hash guard for ON',
        extra_post_budget_evaluation_s=0,source_commit=m['base_commit'])
    plan['memory_at_freeze']=memory_observation()
    save(plan_file,plan);save(str(plan_file)+'.identity.json',dict(sha256=sha(plan_file)))
    return plan


def check_plan(path, check=lambda: None):
    p=read(path)
    if sha(path)!=read(str(path)+'.identity.json')['sha256']:raise ValueError('PLAN_DRIFT')
    if (p['schema']!=SCHEMA or p['seconds']!=LIMIT or p['arms']!=list(ARMS)
        or p['watchdog_s']!=380 or p['extra_post_budget_evaluation_s']!=0
        or Path(p['root']).resolve()!=ROOT or p['environment']!=environment()):raise ValueError('PLAN_ENVIRONMENT_DRIFT')
    check();m=verify(check=check)
    if sha(ROOT/'bundle_manifest.json')!=p['manifest_sha256'] or sha(p['matlab'])!=p['matlab_sha256']:
        raise ValueError('LOCAL_IDENTITY_DRIFT')
    if sha(p['probe_file'])!=p['probe_sha256']:raise ValueError('PROBE_DRIFT')
    check();return p,m


def worker(plan_file, arm, out, start, token, expected):
    folder=Path(out).resolve();folder.mkdir(parents=True,exist_ok=False)
    def early_check():
        if time.monotonic()>=start+LIMIT:raise TimeoutError('BUDGET_DURING_SOURCE_IMPORT_PREPARATION')
    body_started=utc();result=None;guard=None;cleanup=None
    try:
        claim=read(str(plan_file)+'.claim.json')
        if claim['token']!=token or folder != Path(claim['output'])/arm:raise ValueError('WORKER_CLAIM_MISMATCH')
        slot=read(Path(claim['output'])/(arm+'_claim.json'))
        if slot['start_monotonic']!=start or slot['token']!=token or slot['expected_seed']!=expected:
            raise ValueError('WORKER_SLOT_IDENTITY')
        early_check();p,m=check_plan(plan_file,early_check)
        sys.path.insert(0,str(ROOT/'research/chapter3_experiments'))
        from milp import build_model,decode,_digest
        from matlab_bridge import MatlabSession,_prepare,cleanup_is_complete
        from formal_milp import solve_formal_diagnostic
        from initial_point import solve_with_initial_witness
        from pair_lifecycle import execute_milp
        b=anchor_budget(start);b.check()
        event(folder,'PREPARATION_COMPLETE',elapsed_s=b.elapsed,interpreter_entry_monotonic=ENTRY_MONOTONIC,
            memory=memory_observation())
        holder={}
        def loader(budget):
            instance=read(ROOT/m['instance_file']);config=read(ROOT/m['config_file'])
            holder['input_hash']=_digest(instance);return config,instance
        def builder(instance,config,**kw):
            model=build_model(instance,config,**flags(m,arm),**kw);holder['model']=model;return model
        def factory(workdir,**kw):
            nonlocal guard
            s=isolated_session(workdir,matlab_path=p['matlab'],**kw)
            s=represented_session(s)
            guard=Guard(s,folder/'method/initial_receipt_checkpoint.json',holder['input_hash'],expected,
                lambda x:decode(holder['model'],x),_prepare,folder)
            return guard
        def solve(model,session,accuracy,budget):
            def checkpoint(initial):
                save(folder/'method/initial_receipt_checkpoint.json',dict(initialisation=initial,publication_started_at_s=budget.elapsed))
            return solve_with_initial_witness(model,session,accuracy,budget,max_attempts=3,checkpoint=checkpoint,
                diagnostic_solver=partial(solve_formal_diagnostic,feedback_kind='conditional'))
        result=execute_milp(loader,folder/'method',seconds=LIMIT,construct_only=False,
            model_builder=builder,session_factory=factory,solve=solve,method_budget=b)
        if guard is not None:cleanup=cleanup_is_complete(guard.cleanup)
        elif result.get('startup_cleanup') is not None:cleanup=cleanup_is_complete(result['startup_cleanup'])
        else:cleanup=None if result.get('stop_stage')=='solver_startup' else True
        summary=accepted_summary(result)
        summary.update(status='FINISHED',seed_guard=guard.record if guard else {'status':'NOT_REACHED'},
            cleanup_complete=cleanup,flags=flags(m,arm),result_path='method/result.json',
            technical_error=bool(result.get('error') or result.get('cleanup_error') or
                any(s in str(result.get('reason')) for s in ['INTERFACE','NUMERICAL'])))
    except BaseException as e:
        summary=dict(status='FAILED_OR_EXPIRED',reason=type(e).__name__+': '+str(e),
            traceback=traceback.format_exc(),accepted_in_budget_safe=False,cleanup_complete=cleanup,
            seed_guard=guard.record if guard else {'status':'NOT_REACHED'})
    try:
        verify(); summary['source_integrity_after']=True
    except Exception as e:
        summary.update(source_integrity_after=False,technical_error=True,integrity_error=str(e))
    summary.update(arm=arm,started_utc=body_started,ended_utc=utc(),method_origin_monotonic=start,
        worker_entry_monotonic=ENTRY_MONOTONIC,total_process_elapsed_s=time.monotonic()-start,
        seconds=LIMIT,post_budget_work='Cleanup/serialization only; zero new scientific evidence')
    save(folder/'slot_result.json',summary);return summary


def kill_owned(proc, created):
    import psutil
    root=psutil.Process(proc.pid)
    if root.create_time()!=created:raise RuntimeError('PROCESS_IDENTITY_CHANGED')
    children=root.children(recursive=True)
    for child in children:child.kill()
    root.kill();gone,alive=psutil.wait_procs(children+[root],timeout=10)
    return dict(captured=[p.pid for p in children]+[proc.pid],alive=[p.pid for p in alive],complete=not alive)


def run(plan_file, output, execute=False):
    if not execute:raise ValueError('EXPLICIT_EXECUTE_FLAG_REQUIRED')
    p,m=check_plan(plan_file)
    import psutil,secrets
    out=Path(output).resolve();out.mkdir(parents=True,exist_ok=False)
    token=secrets.token_hex(16);save(str(plan_file)+'.claim.json',dict(token=token,output=str(out),utc=utc()))
    expected=None;results=[]
    for arm in ARMS:
        start=time.monotonic()
        save(out/(arm+'_claim.json'),dict(start_monotonic=start,token=token,expected_seed=expected,utc=utc(),
            memory=memory_observation()))
        cmd=[sys.executable,'-B',str(Path(__file__).resolve()),'_worker','--plan',str(Path(plan_file).resolve()),
            '--arm',arm,'--out',str(out/arm),'--start',repr(start),'--token',token]
        if expected is not None:cmd+=['--expected-seed',expected]
        event(out,'LAUNCH',arm=arm,argv=cmd,start_monotonic=start)
        with (out/(arm+'.stdout.log')).open('w') as stdout,(out/(arm+'.stderr.log')).open('w') as stderr:
            proc=subprocess.Popen(cmd,cwd=ROOT,stdout=stdout,stderr=stderr)
            created=psutil.Process(proc.pid).create_time()
            try:code=proc.wait(timeout=max(.001,start+p['watchdog_s']-time.monotonic()))
            except subprocess.TimeoutExpired:
                try:receipt=kill_owned(proc,created)
                except Exception as e:receipt={'complete':False,'error':type(e).__name__+': '+str(e)}
                save(out/(arm+'_watchdog.json'),receipt)
                results.append(dict(arm=arm,status='WATCHDOG_TIMEOUT',cleanup=receipt));break
        event(out,'WORKER_RETURN',arm=arm,returncode=code,wall_s=time.monotonic()-start)
        f=out/arm/'slot_result.json'
        if code or not f.exists():results.append(dict(arm=arm,status='WORKER_FAILED',returncode=code));break
        result=read(f);results.append(result)
        if (result.get('status')!='FINISHED' or result.get('cleanup_complete') is not True
            or result['seed_guard']['status']!='PASSED' or result.get('technical_error')
            or result.get('source_integrity_after') is not True):break
        if arm=='off':expected=result['seed_guard']['candidate_sha256']
    valid=len(results)==2 and all(r.get('cleanup_complete') is True and r.get('seed_guard',{}).get('status')=='PASSED'
        and not r.get('technical_error') and r.get('source_integrity_after') is True for r in results)
    summary=dict(ended_utc=utc(),results=results,pair_initialization_and_cleanup_valid=valid,
        omitted_arms=[a for a in ARMS if a not in [r['arm'] for r in results]],
        retries=0,optimality_proven=False,scope='Single pair; inspect native results/budgets, not a solver-performance success flag')
    save(out/'pair_summary.json',summary);return summary


def main():
    p=argparse.ArgumentParser(description=__doc__);sub=p.add_subparsers(dest='command',required=True)
    sub.add_parser('verify')
    q=sub.add_parser('probe');q.add_argument('--matlab',required=True);q.add_argument('--out',required=True)
    q=sub.add_parser('freeze');q.add_argument('--probe',required=True);q.add_argument('--plan',required=True)
    q=sub.add_parser('run');q.add_argument('--plan',required=True);q.add_argument('--out',required=True);q.add_argument('--execute',action='store_true')
    q=sub.add_parser('_worker');q.add_argument('--plan',required=True);q.add_argument('--arm',choices=ARMS,required=True);q.add_argument('--out',required=True);q.add_argument('--start',type=float,required=True);q.add_argument('--token',required=True);q.add_argument('--expected-seed')
    a=p.parse_args()
    if a.command=='verify':r={'verified_files':len(verify()['files']),'solver_calls':0}
    elif a.command=='probe':r=probe(a.matlab,a.out)
    elif a.command=='freeze':r=freeze(a.probe,a.plan)
    elif a.command=='run':r=run(a.plan,a.out,a.execute)
    else:r=worker(a.plan,a.arm,a.out,a.start,a.token,a.expected_seed)
    print(json.dumps(r,ensure_ascii=False))

if __name__=='__main__':main()
