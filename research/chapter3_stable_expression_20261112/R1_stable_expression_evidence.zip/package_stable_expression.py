from pathlib import Path
import hashlib,json,re,shutil,zipfile
W=Path(__file__).resolve().parent;OUT=W.parent/'outputs';R=W/'stable_expression'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
files=[];excluded=[]
for folder in ['stable_expression','equality_pair_source']:
    for p in sorted((W/folder).rglob('*')):
        if not p.is_file():continue
        rel=p.relative_to(W)
        if any(x in ['isolated_preferences','isolated_matlab_preferences','.runtime','temp','small_temp','__pycache__'] for x in rel.parts):
            excluded.append(rel.as_posix());continue
        assert p.suffix.lower() not in ['.pem','.p12']
        files.append((p,rel.as_posix()))
shutil.copyfile(R/'RESEARCH_ROUTE.txt',OUT/'完整MILP三阶段研究路线.txt')
files.extend([(OUT/'R1稳定数值表达首轮验收报告.txt','R1稳定数值表达首轮验收报告.txt'),(Path(__file__),'package_stable_expression.py')])
pattern=re.compile(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----|gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{50,}')
for p,name in files:
    if p.suffix in ['.py','.json','.log','.txt','.m']:assert not pattern.search(p.read_bytes()),name
manifest=dict(files=[dict(path=name,bytes=p.stat().st_size,sha256=sha(p)) for p,name in files],excluded_runtime_files=excluded,credential_pattern_scan='clear',
    scientific_scope='One mathematically equivalent representation candidate, small enumerable verification, full saved-matrix certificates, and one failed native OFF entry; later slots stopped as authorized.')
archive=OUT/'R1稳定数值表达首轮证据.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p,name in files:z.write(p,name)
    z.writestr('MANIFEST_SHA256.json',json.dumps(manifest,ensure_ascii=False,indent=2))
with zipfile.ZipFile(archive) as z:
    for item in manifest['files']:
        h=hashlib.sha256()
        with z.open(item['path']) as f:
            for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
        assert h.hexdigest()==item['sha256'],item['path']
receipt=dict(archive=archive.name,sha256=sha(archive),bytes=archive.stat().st_size,verified_files=len(files),all_checksums_match=True)
with (OUT/'稳定表达交付校验.json').open('x',encoding='utf-8') as f:json.dump(receipt,f,ensure_ascii=False,indent=2)
print(json.dumps(receipt,ensure_ascii=False))
