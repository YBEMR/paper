"""Read-only stage summary and report, never a scientific execution entry."""
from pathlib import Path
import json,hashlib
R=Path(__file__).resolve().parent;OUT=R.parent.parent/'outputs'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
summary=read(R/'entry_runs/summary.json');plan=read(R/'entry_plan.json');small=read(R/'small_run/results.json');full=read(R/'full/summary.json')
assert small['passed'] and full['passed']
assert sha(R/'entry_plan.json')==read(R/'entry_plan_identity.json')['sha256']
assert all(sha(Path(name))==h for name,h in plan['frozen_files'].items())
assert summary['observed_native_calls']<=4 and summary['retries']==0
records=[]
for r in summary['receipts']:
    initial=r.get('initial_evaluation') or {};final=r.get('returned_candidate_evaluation') or {}
    records.append(dict(slot=r['slot'],passed=r['passed'],native_calls=r.get('native_calls'),native_exitflag=r.get('native_exitflag'),
        native_status=r.get('native_status'),method_elapsed_s=r.get('method_elapsed_s'),total_elapsed_s=r.get('total_elapsed_s'),
        first_root_or_later=r.get('root_or_later_first'),last_reported_bound=r.get('last_reported_bound'),
        initial_SAFE_energy=initial.get('safe_upper_bound_J'),returned_SAFE_energy=final.get('safe_upper_bound_J'),
        same_initial=r.get('same_initial'),strict_improvement=r.get('strict_interval_energy_improvement'),
        checks=r.get('checks'),error=r.get('error'),auxiliary_errors=r.get('auxiliary_errors'),
        original_row_admission=r.get('original_row_admission'),transformed_row_admission=r.get('transformed_row_admission')))
final=dict(representation='complement_gate_split_constant_v1',small_gate_passed=True,full_exact_gate_passed=True,
    full_entry_acceptance_passed=summary['passed'],records=records,omitted_slots=summary['omitted_slots'],
    native_calls=summary['observed_native_calls'],retries=0,formal_ABC_comparisons=0,full_R1_rebuilds=0,
    small_physical_models=3,small_complete_evaluations=36,source_identity_after=True,
    full_static_preparation_s=full['elapsed_s'],entry_plan_sha256=sha(R/'entry_plan.json'),
    next_stage='Freeze fair A/B/C protocol after separately checking A entry; no automatic performance execution' if summary['passed'] else 'Stage A remains open. Stop this candidate native runs; use the failed gate to design the next algebraic formulation, not repeated unchanged solves.',
    evidence_scope='Exact projection equivalence and one enumerable physical fixture are proved; native stability is assessed only by the frozen R1 slots. No model-size or entry-time result is a formal performance gain.')
with (R/'stage_summary.json').open('x',encoding='utf-8') as f:json.dump(final,f,ensure_ascii=False,indent=2)
result='完整R1的OFF、ON各两次入口验收通过。可准备统一表达下的A/B/C正式协议，但尚不能宣称约简带来求解收益。' if summary['passed'] else '完整R1入口验收未全部通过，已按约定停止后续槽位。本候选尚不能作为统一的稳定数值表达；MILP路线继续，阶段一仍未完成。'
lines=[
'完整电热 MILP 稳定表达：首个候选实现与有限入口验收（2026-11-12）','',
'研究目标已调整为实现并验证较大规模完整MILP的有效求解；不以模型规模下降或反复证明矩阵可行替代求解成果。',result,'',
'一、互补门控与精确常数展开',
'原条件行 a*x+alpha*g<=b，引入连续h=1-g、0<=h<=1，改写为a*x-alpha*h<=b-alpha。保留原变量及其界、原目标和原整数集合；不固定调度，不修改物理系数或评价精度。',
'不把正宽度区间压成等式。右端若不能精确存为一个binary64，则精确分解r=hi+lo，引入固定连续t=lo，并用a*x-alpha*h-t<=hi表示。hi、lo必须都能精确存回binary64，否则拒绝。',
'OFF与ON各有一条需要高低常数展开的行。逐行精确逆代入证明整个连续松弛和整数调度投影保持不变；这只是数学等价，不保证原生稳定性。',
'数值风险：原行残差可能含alpha*(g+h-1)+(t-lo)。即便新行在容差内，也须回到原行检查；对所有返回候选同时做新／原矩阵检查，再独立验证调度和完整电热SAFE。','',
'二、小实例门槛',
'采用原物理参数的单场景A.pre Stage，保留CPU1/CPU2×L/M/H六模式，开始时刻为0、125ms；12个Cartesian调度含6合法和6期限非法。测试场景权重归一为1仅用于小实例聚合。',
'A/B/C三个完整物理小模型共36次结构投影检查、36次完整电热评价；坐标逆映射、解码、合法调度集合及物理科学字段均一致。20项转换／入口纯测试通过。',
'此小域三组保留选项相同，不能据此声称两级约简贡献；也不能把一个小实例推广为一般数值稳定性。','',
'三、完整保存矩阵与入口协议',
'源矩阵来自efcbb8e，之前证据链包括bb3838d与100e5d2。完整R1保持12次Stage，原OFF对应支持传播开启／联合剪枝关闭，ON对应两级均开启。',
'OFF：原19857变量 → 29656变量，124338不等式＋9798等式；ON：原16919变量 → 23780变量，94958不等式＋6860等式。新增变量为互补门控和一个固定常数列，不能把该候选描述成更小模型。',
f'保存矩阵的转换、逐行认证、选项身份恢复与归档准备共{full["elapsed_s"]:.3f}秒，发生在入口计划冻结前。以后正式A/B/C必须将转换认证计入各组总成本，不能把这里的预计算当免费方法步骤。',
'用户明确选择最多4槽：OFF1、ON1，首次都通过后OFF2、ON2；任一失败即停，无重试。每槽父进程起点300秒，原生MaxTime固定240秒，其他原生选项／求解脚本保持不变；预留读取、回投及完整评价时间，不延长总窗。',
'使用保存矩阵与保存x0，原有整数变量均自由；每槽重新完整评价共同初解，再对最多一个最终原生候选作完整评价。仅恢复原有选项列映射，不重建R1电热模型。',
'通过必须同时满足及时SOLVED且exitflag1/2、原生准入标志、实际传输一致、新／原行准入、完整SAFE、有限原生下界、根LP或后续阶段、来源不变与清理完整。入口不等于性能比较；复现初解不算节能或新调度。',
f'冻结计划SHA256：{sha(R/"entry_plan.json")}',
f'本轮实际原生调用：{summary["observed_native_calls"]}；省略槽：{summary["omitted_slots"]}；重试0；A/B/C性能对照0。','']
for r in records:
    lines += [r['slot']+': '+('通过' if r['passed'] else '未通过'),
        f"  exitflag={r['native_exitflag']}；方法时长={r['method_elapsed_s']}；含清理总时长={r['total_elapsed_s']}。",
        f"  初解SAFE能耗={r['initial_SAFE_energy']}；返回候选SAFE能耗={r['returned_SAFE_energy']}。",
        f"  与初解相同={r['same_initial']}；能耗区间严格改善={r['strict_improvement']}。",
        '  未通过项='+str([k for k,v in (r['checks'] or {}).items() if not v]),
        '  异常='+str(r['error']),
        '  最后原生下界='+str(r['last_reported_bound']),
        '  互补／常数实际误差='+str(r['auxiliary_errors']),'']
lines += ['四、后续路线与结论边界',
'目标A先找到稳定完整电热MILP表达。若本候选门槛失败，保留精确等价与失败证据，先据失败环节研究下一表达；不把停止本候选误写成放弃MILP，也不原样追加300秒。',
'目标B为完整12次Stage的A/B/C：A期限过滤基线；B=A＋选项支持传播；C=B＋联合状态剪枝。其余工程优化、任务、物理参数、初解规则、数值表达、求解器、评价器和总预算一致。',
'指标区分：外部初解、原生返回同初解、原生返回不同且完整SAFE、严格能耗改善；同时记录根LP／回调／下界／gap和构模、转换、认证、求解、评价的全成本。',
'所有界首先按solver-reported记录，绑定问题、时刻和目标单位；没有独立证书不能写成严格最优性。能耗严格改善要求新上界低于初解下界。',
'只有统一预算下C相对A/B出现可验证实质优势后，才推广其他完整负载／期限；若三组仍难求解，则研究分解或更紧凑表达，而非宣称规模问题已解决。',
'其他求解器只完成环境盘点：MATLAB有历史授权与运行证据；SciPy安装含HiGHS包装器，尚未验证此实例适用性。未发现其他包装器不等于机器绝无商业授权。若切换，三组必须统一使用同一求解器重新冻结，不能混用结果宣称剪枝加速。',
'详见证据包中的RESEARCH_ROUTE.txt、冻结小实例计划、完整逐行证书、入口计划、原生回执和stage_summary.json。']
with (OUT/'R1稳定数值表达首轮验收报告.txt').open('x',encoding='utf-8') as f:f.write('\n'.join(lines)+'\n')
print(json.dumps(final,ensure_ascii=False,indent=2))
