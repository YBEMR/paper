from pathlib import Path
import subprocess,sys,time,json,os
r=Path(__file__).resolve().parent
temp=r/'small_temp';temp.mkdir(exist_ok=False)
cmd=[sys.executable,'-B',str(r/'validate_small.py'),'run','--plan',str(r/'small_plan.json'),'--out',str(r/'small_run')]
start=time.monotonic()
with (r/'small.stdout.log').open('x') as stdout,(r/'small.stderr.log').open('x') as stderr:
    proc=subprocess.Popen(cmd,stdout=stdout,stderr=stderr,env=dict(os.environ,TEMP=str(temp),TMP=str(temp),TMPDIR=str(temp)),creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
    try:code=proc.wait(timeout=600)
    except subprocess.TimeoutExpired:
        import psutil
        root=psutil.Process(proc.pid);children=root.children(recursive=True)
        for p in children:p.kill()
        root.kill();psutil.wait_procs([root,*children],timeout=10);code=-1
(r/'small_controller.json').write_text(json.dumps(dict(returncode=code,wall_s=time.monotonic()-start,watchdog_s=600)),encoding='utf-8')
print((r/'small.stdout.log').read_text());print((r/'small.stderr.log').read_text());sys.exit(code)
