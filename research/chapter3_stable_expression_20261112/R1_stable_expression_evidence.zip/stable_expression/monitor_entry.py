from pathlib import Path
import json,time
r=Path(__file__).resolve().parent/'entry_runs'
for slot in ['off1','on1','off2','on2']:
    f=r/slot
    if not f.exists():continue
    if (f/'receipt.json').exists():
        d=json.loads((f/'receipt.json').read_text(encoding='utf-8'))
        print(slot,{k:d.get(k) for k in ['passed','native_exitflag','method_elapsed_s','same_initial','strict_interval_energy_improvement','checks','error']})
    elif (f/'claim.json').exists():
        d=json.loads((f/'claim.json').read_text(encoding='utf-8'));print(slot,'elapsed',round(time.monotonic()-d['start_monotonic'],3))
        p=f/'progress.jsonl'
        if p.exists():
            lines=p.read_text(encoding='utf-8').splitlines()
            for line in lines[-2:]:print(json.loads(line))
if (r/'summary.json').exists():
    d=json.loads((r/'summary.json').read_text(encoding='utf-8'));print('SUMMARY',{k:v for k,v in d.items() if k!='receipts'})
