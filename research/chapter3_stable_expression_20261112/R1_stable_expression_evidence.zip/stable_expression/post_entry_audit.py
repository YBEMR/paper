"""Read-only archived transport audit, without late candidate evaluation."""
from pathlib import Path
import json
from run_entry import ROOT,read,save,payload,verify_plan,array_digest
plan=verify_plan();summary=read(ROOT/'entry_runs/summary.json');rows=[]
for rec in summary['receipts']:
    folder=ROOT/'entry_runs'/rec['slot'];actual=payload(folder/'matlab/request_000001.mat');expected=payload(ROOT/'full'/(rec['arm']+'.mat'))
    same=array_digest(actual)==array_digest(expected);assert same
    raw=read(folder/'matlab/request_000001.response.json')
    rows.append(dict(slot=rec['slot'],actual_sent_arrays_match=True,original_native_options_match=raw['options']==plan['native_options'],
        raw_status=raw.get('status'),raw_exitflag=raw.get('exitflag'),raw_message=raw.get('output',{}).get('message'),
        returned_vector_present=bool(raw.get('x')),returned_candidate_identity_comparison='NOT_APPLICABLE' if not raw.get('x') else 'See in-budget receipt',
        actual_native_call_s=raw.get('phase_seconds',{}).get('intlinprog_call'),
        interpretation='The in-budget boolean actual_transport_matches=false means not reached after native gate rejection, not an observed transport mismatch. The failed acceptance record is preserved.'))
save(ROOT/'post_entry_audit.json',dict(passed=all(r['actual_sent_arrays_match'] and r['original_native_options_match'] for r in rows),rows=rows,
    solver_calls=0,model_builds=0,thermal_evaluations=0,does_not_change_entry_failure=True))
report=ROOT.parent.parent/'outputs/R1稳定数值表达首轮验收报告.txt'
with report.open('a',encoding='utf-8') as f:
    f.write('\n只读归档补充核查：实际送入MATLAB的全部数组与冻结新表达完全一致，原生选项与冻结值完全一致。\n')
    for r in rows:
        f.write(f"{r['slot']}：原生status={r['raw_status']}，exitflag={r['raw_exitflag']}，实际intlinprog调用{r['actual_native_call_s']}秒；返回向量存在={r['returned_vector_present']}。原生信息：{r['raw_message']}\n")
    f.write('本次未返回候选；same_initial=false不表示找到不同调度，该比较不适用。actual_transport_matches=false等原入口字段因前置原生门槛失败而未执行，不能解释为数组不一致；本次只读核对不回填或改写原失败回执，也不构成预算内求解收益。\n')
print(json.dumps(rows,ensure_ascii=False,indent=2))
