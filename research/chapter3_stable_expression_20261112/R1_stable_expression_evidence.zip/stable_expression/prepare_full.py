"""Prepare saved R1 arrays and exact complement certificates; no R1 rebuild."""
from pathlib import Path
from fractions import Fraction as Q
import hashlib,json,sys,zipfile,shutil,time
import numpy as np
from scipy.io import loadmat,savemat
import complement_gate as cg
R=Path(__file__).resolve().parent;W=R.parent;S=W/'equality_pair_source';SCI=S/'research/chapter3_experiments'
sys.path.insert(0,str(SCI))
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):
    with p.open('x',encoding='utf-8') as f:json.dump(x,f,ensure_ascii=False,indent=2)
def load(p):
    raw=loadmat(p);d={k:raw[k].tocsc() if k in ['A','Aeq'] else raw[k].reshape(-1) for k in cg.KEYS}
    assert np.equal(d['intcon'],np.floor(d['intcon'])).all();d['intcon']=d['intcon'].astype(np.int64)-1;return d
def save_native(p,d):
    n={k:v.copy() for k,v in d.items()};n['intcon']=(d['intcon']+1).astype(np.float64)
    savemat(p,n,do_compression=True,oned_as='column')
    assert cg.array_digest(load(p))==cg.array_digest(d)
def key(candidate):
    return sorted((sid,row['stage_id'],row['unit'],row['opp'],str(Q(row['start_ms']))) for sid,rows in candidate['scenes'].items() for row in rows)
def main():
    start=time.monotonic();out=R/'full';out.mkdir(exist_ok=False)
    archive=W/'publish_repo/research/chapter3_native_pruning_pair_20261112/R1_native_pair_evidence.zip'
    expected=read(W.parent/'outputs/交付校验.json')['sha256'];assert sha(archive)==expected
    with zipfile.ZipFile(archive) as z:
        lookup={item['path']:item['sha256'] for item in json.loads(z.read('MANIFEST_SHA256.json'))['files']}
        for arm in ['off','on']:
            for name,newname in [('matlab/request_000001.mat',arm+'.original.mat'),('result.json',arm+'.historical_result.json')]:
                path='execution/pair/'+arm+'/method/'+name;data=z.read(path);assert hashlib.sha256(data).hexdigest()==lookup[path];(out/newname).write_bytes(data)
    for name in ['input_instance.json','input_config.json']:shutil.copyfile(S/'inputs'/name,out/name)
    instance=read(out/'input_instance.json');config=read(out/'input_config.json')
    seed=read(out/'off.historical_result.json')['initialisation']['witness']['candidate'];save(out/'initial_candidate.json',seed)
    from inputs import expand_options
    from option_support import propagate_option_support
    from timing import MethodBudget
    budget=MethodBudget(60)
    options=expand_options(instance,config,budget=budget)
    options=[o for o in options if Q(o['end_ms'])<=Q(o['request_deadline_ms'])]
    options,support=propagate_option_support(instance,options,budget=budget)
    save(out/'option_support_identity.json',support)
    summaries=[];sizes={}
    for arm in ['off','on']:
        p=load(out/(arm+'.original.mat'));sizes[arm]=len(p['c'])
        assert np.array_equal(p['intcon'],np.arange(len(options)))
        candidate={'scenes':{s['id']:[] for s in instance['scenarios']}}
        for j,o in enumerate(options):
            assert p['x0'][j] in (0,1)
            if p['x0'][j]:candidate['scenes'][o['scenario_id']].append(dict(stage_id=o['stage_instance_id'],unit=o['unit_id'],opp=o['opp_id'],start_ms=o['start_ms']))
        assert key(candidate)==key(seed)
        a=p['A'].tocsr();mapping={};pairs=[]
        for i in range(a.shape[0]-1):
            li=slice(a.indptr[i],a.indptr[i+1]);ri=slice(a.indptr[i+1],a.indptr[i+2])
            ix=a.indices[li];jx=a.indices[ri];av=a.data[li];bv=a.data[ri]
            if not np.array_equal(ix,jx):continue
            different=np.flatnonzero(av!=-bv)
            if len(different)!=1:continue
            k=int(different[0]);g=int(ix[k]);sm=Q.from_float(float(av[k]))+Q.from_float(float(bv[k]))
            if sm<=0 or p['lb'][g]!=0 or p['ub'][g]!=1:continue
            assert i not in mapping and i+1 not in mapping
            mapping[i]=g;mapping[i+1]=g;pairs.append([i,i+1,g])
        assert pairs
        save(out/(arm+'.gate_rows.json'),dict(pairs=pairs,scope='Exact adjacent row coefficient pattern with one 0..1 gate; no semantic tag inferred. Substitution is valid for each explicitly recorded row regardless of its origin.'))
        d,c=cg.transform(p,row_gates=mapping,gate_columns=sorted(set(mapping.values())),mode='split_constant_v1')
        assert all(c['checks'].values());assert np.array_equal(d['lb'][:len(p['c'])],p['lb']) and np.array_equal(d['ub'][:len(p['c'])],p['ub'])
        assert np.array_equal(cg.inverse_vector(d['x0'],c),p['x0'])
        save_native(out/(arm+'.mat'),d);save(out/(arm+'.certificate.json'),c)
        summaries.append(dict(arm=arm,original_variables=len(p['c']),derived_variables=len(d['c']),inequalities=d['A'].shape[0],equalities=d['Aeq'].shape[0],conditional_pairs=len(pairs),gate_columns=len(set(mapping.values())),added_fixed_offset_columns=len(d['c'])-len(p['c'])-len(set(mapping.values())),passed=True,original_array_sha256=cg.array_digest(p),derived_array_sha256=cg.array_digest(d)))
        print(json.dumps(summaries[-1]),flush=True)
    save(out/'options.json',dict(options=options,original_variables=sizes,metadata=dict(count=len(options),order_rule='Unchanged expand_options, deadline filter, option_support; intcon exactly first option count; archived full SAFE seed decode matched on both arms.',full_model_builds=0)))
    result=dict(passed=True,arms=summaries,source_commit='efcbb8e28d43fbebc830f21bc6648af282378370',source_archive_sha256=expected,code_sha256={p.name:sha(p) for p in [Path(__file__),R/'complement_gate.py']},files={p.name:sha(p) for p in out.iterdir() if p.is_file()},full_model_builds=0,native_calls=0,thermal_evaluations=0,elapsed_s=time.monotonic()-start)
    save(out/'summary.json',result)
if __name__=='__main__':main()
