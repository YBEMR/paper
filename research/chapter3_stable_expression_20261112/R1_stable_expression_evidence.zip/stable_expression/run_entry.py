"""At most four pre-frozen R1 native entry checks; fail stops all later slots.

No model builder, changed integer bound, callback thermal evaluation, feedback,
retry, performance comparison or post-budget candidate evaluation is permitted.
"""
import time
ENTRY_TIME=time.monotonic()
from pathlib import Path
from fractions import Fraction
import argparse,hashlib,json,math,os,subprocess,sys,traceback
import numpy as np
from scipy.io import loadmat
from complement_gate import KEYS,array_digest,verify_equivalence,inverse_vector

ROOT=Path(__file__).resolve().parent
SOURCE=ROOT.parent/'equality_pair_source'
SCIENCE=SOURCE/'research/chapter3_experiments'
SLOTS=(('off',1),('on',1),('off',2),('on',2))
METHOD_SECONDS=300.0
NATIVE_MAXTIME=240.0
WATCHDOG_SECONDS=380.0

def read(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def digest(value):return hashlib.sha256(json.dumps(value,sort_keys=True,ensure_ascii=False,separators=(',',':'),default=str).encode()).hexdigest()
def save(path,value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('x',encoding='utf-8',newline='\n') as f:json.dump(value,f,ensure_ascii=False,indent=2,allow_nan=False)
def payload(path):
    d=loadmat(path,variable_names=list(KEYS))
    p={k:d[k].tocsc() if k in ('A','Aeq') else d[k].reshape(-1) for k in KEYS}
    raw=p['intcon'];assert np.isfinite(raw).all() and np.equal(raw,np.floor(raw)).all()
    p['intcon']=raw.astype(np.int64)-1
    return p
def same_schedule(left,right):
    def normal(c):return {sid:sorted((r['stage_id'],r['unit'],r['opp'],Fraction(r['start_ms'])) for r in rows) for sid,rows in c['scenes'].items()}
    return normal(left)==normal(right)
def original_coordinates_unchanged(original,derived,certificate):
    n=len(original['c'])
    if n!=certificate['original_variables']:raise ValueError('Wrong original variable count')
    for key in ['lb','ub','c','x0']:
        if not np.array_equal(original[key],derived[key][:n]):raise ValueError('Original coordinate changed: '+key)
    if not np.array_equal(original['intcon'],derived['intcon']):raise ValueError('Original integer columns changed')
    return True
def decode_options(instance,options,vector,tolerance,validate_schedule):
    values=np.asarray(vector,dtype=float).reshape(-1)
    if len(values)<len(options) or not np.isfinite(values).all():raise ValueError('Invalid decoder vector')
    selected=values[:len(options)]
    if (np.abs(selected-np.rint(selected))>tolerance).any() or (selected < -tolerance).any() or (selected > 1+tolerance).any():
        raise ValueError('Option coordinate is not a numerical binary')
    candidate={'scenes':{s['id']:[] for s in instance['scenarios']}}
    for option,value in zip(options,selected):
        if round(float(value))==1:
            candidate['scenes'][option['scenario_id']].append(dict(stage_id=option['stage_instance_id'],unit=option['unit_id'],opp=option['opp_id'],start_ms=option['start_ms']))
    checked=validate_schedule(instance,candidate)
    if checked.get('state')!='SCHEDULE_VALID_THERMAL_UNCHECKED':raise ValueError('Independent schedule legality rejected: '+str(checked.get('reason')))
    return candidate,checked
def full_safe(evaluation,scenario_count,seconds=METHOD_SECONDS):
    return bool(evaluation and evaluation.get('state')=='SAFE' and evaluation.get('rankable_energy') and
        evaluation.get('completed_at_elapsed_s',seconds)<seconds and len(evaluation.get('scenes',{}))==scenario_count and
        all(v.get('complete') and v.get('state')=='SAFE' for v in evaluation.get('scenes',{}).values()))
def bounded_progress(events,seconds=METHOD_SECONDS):
    accepted=[e for e in events if 0<=e.get('method_elapsed_s',seconds)<seconds]
    later=[e for e in accepted if e.get('values',{}).get('phase') in ['rootlp','heuristics','cutgen','branching']]
    bounds=[e for e in accepted if isinstance(e.get('values',{}).get('lowerbound'),(float,int)) and not isinstance(e['values']['lowerbound'],bool) and math.isfinite(e['values']['lowerbound'])]
    return later,bounds
def should_continue(receipts):
    return len(receipts)<len(SLOTS) and all(r.get('passed') is True for r in receipts)
def bind_budget(budget_class,start,seconds):
    budget=budget_class(seconds);budget.start=start;budget.deadline=start+seconds
    return budget
def native_admissible(returned):
    return bool(returned and returned.get('status')=='SOLVED' and returned.get('accepted_for_evaluation') is True and
        returned.get('budget_valid') is True and returned.get('exitflag') in (1,2) and returned.get('x'))
def complement_error(vector,certificate):
    q=lambda v:Fraction.from_float(float(v))
    residuals=[abs(q(vector[r['gate_column']])+q(vector[r['complement_column']])-1) for r in certificate['gate_complements']]
    offsets=[abs(q(vector[r['column']])-Fraction(r['value_exact'])) for r in certificate.get('fixed_constants',[])]
    a=max(residuals,default=Fraction(0));b=max(offsets,default=Fraction(0))
    return dict(maximum_gate_complement_residual_exact=str(a),maximum_gate_complement_residual_float=float(a),
        maximum_fixed_offset_residual_exact=str(b),maximum_fixed_offset_residual_float=float(b),
        interpretation='Exact residuals of binary64 returned auxiliaries; original-row admission separately checks any amplification by original gate coefficients.')

def prepare(small_receipt,full_receipt):
    small_receipt=Path(small_receipt).resolve();full_receipt=Path(full_receipt).resolve()
    if read(small_receipt).get('passed') is not True:raise ValueError('Small enumerable gate did not pass')
    full_gate=read(full_receipt)
    if full_gate.get('passed') is not True:raise ValueError('Full static transformation gate did not pass')
    small_plan_file=ROOT/'small_plan.json';small_identity=ROOT/'small_plan.json.identity.json'
    if sha(small_plan_file)!=read(small_identity)['sha256']:raise ValueError('Small plan identity drift')
    small_plan=read(small_plan_file)
    for name,h in small_plan['source_sha256'].items():
        if sha(name)!=h:raise ValueError('Small-tested source no longer matches: '+name)
    for name,h in full_gate['files'].items():
        if sha(full_receipt.parent/name)!=h:raise ValueError('Full-prepared input drift: '+name)
    for name,h in full_gate['code_sha256'].items():
        if sha(ROOT/name)!=h:raise ValueError('Full-prepared source drift: '+name)
    sys.path.insert(0,str(SCIENCE));import matlab_bridge as bridge
    from schedules import validate_schedule
    instance=read(ROOT/'full/input_instance.json');initial=read(ROOT/'full/initial_candidate.json')
    option_doc=read(ROOT/'full/options.json');options=option_doc['options']
    initial_identity={};original_manifest=read(SOURCE/'bundle_manifest.json')
    for name,h in original_manifest['files'].items():
        if sha(SOURCE/name)!=h:raise ValueError('Original source drift: '+name)
    for arm in ['off','on']:
        old=payload(ROOT/'full'/(arm+'.original.mat'));new=payload(ROOT/'full'/(arm+'.mat'));cert=read(ROOT/'full'/(arm+'.certificate.json'))
        if not cert.get('checks') or not all(cert['checks'].values()):raise ValueError('Certificate has failing checks')
        verify_equivalence(old,new,cert);original_coordinates_unchanged(old,new,cert)
        if option_doc['original_variables'][arm]!=len(old['c']):raise ValueError('Option metadata original length mismatch')
        if not set(range(len(options))).issubset(set(map(int,old['intcon']))):raise ValueError('Option prefix must be original integer columns')
        native=bridge._prepare(old,x0=old['x0']);bridge._prepare(new,x0=new['x0'])
        decoded,legality=decode_options(instance,options,old['x0'],1e-6,validate_schedule)
        if not same_schedule(initial,decoded):raise ValueError('Archived x0 does not decode to common SAFE schedule')
        initial_identity[arm]=dict(candidate_sha256=digest(decoded),native_initial_admission=native['x0_validation'])
    baseline=read(ROOT.parent/'feasibility_r1/sources/original/matlab/request_000001.response.json')['options']
    expected=dict(baseline,MaxTime=NATIVE_MAXTIME)
    bindings={str(SOURCE/name):h for name,h in original_manifest['files'].items()}
    bindings[str(SOURCE/'bundle_manifest.json')]=sha(SOURCE/'bundle_manifest.json')
    for path in list(ROOT.glob('*.py'))+[p for p in (ROOT/'full').rglob('*') if p.is_file()]+[small_receipt,full_receipt,small_plan_file,small_identity,ROOT/'authorization.json',ROOT/'RESEARCH_ROUTE.txt']:
        bindings[str(path.resolve())]=sha(path)
    plan=dict(protocol='full-R1-complement-gate-entry-acceptance-v1',slots=[dict(arm=arm,repetition=rep) for arm,rep in SLOTS],
        seconds=METHOD_SECONDS,native_MaxTime=NATIVE_MAXTIME,watchdog_seconds=WATCHDOG_SECONDS,maximum_native_calls=4,retries=0,
        frozen_files=bindings,small_gate_file=str(small_receipt),full_gate_file=str(full_receipt),
        matlab='F:/Matlab2023/Program_Files/MATLAB_R2023b/bin/matlab.exe',source_manifest_sha256=sha(SOURCE/'bundle_manifest.json'),
        native_options=expected,initial_identity=initial_identity,
        initial_candidate_sha256=digest(initial),input_sha256=digest(instance),
        source_scope='Original numerical worker/evaluator sources byte-identical. No original integer bounds fixed, model building, new pruning, thermal cuts or feedback.',
        initial_scope='Saved common initial schedule and saved completed x0 used for numerical entry acceptance, with a fresh complete physical evaluation in each slot. This is not a formal performance experiment.',
        stop_rule='OFF1, ON1, OFF2, ON2; any failed, expired, invalid or missing receipt stops all remaining slots; no retry and no cross-slot budget transfer.',
        evaluation_limits='One common initial schedule evaluation and at most one final native-returned candidate evaluation per slot, in its parent-origin 300 seconds. Callbacks record progress only.',
        acceptance='Native exitflag 1/2, timely complete return, exact source/transport identity, original-row numerical admission, decoded complete SAFE, finite native lowerbound and rootlp or later phase, clean process exit.',
        evidence_limits='Native lowerbound remains solver-reported, not independently certified. Same-initial candidate and strict interval improvement are reported separately; entry acceptance is not optimization success.')
    save(ROOT/'entry_plan.json',plan);save(ROOT/'entry_plan_identity.json',dict(sha256=sha(ROOT/'entry_plan.json')))
    print(json.dumps(dict(prepared=True,plan_sha256=sha(ROOT/'entry_plan.json'),maximum_native_calls=4)))

def verify_plan():
    if sha(ROOT/'entry_plan.json')!=read(ROOT/'entry_plan_identity.json')['sha256']:raise ValueError('Plan identity drift')
    plan=read(ROOT/'entry_plan.json')
    for name,h in plan['frozen_files'].items():
        if sha(name)!=h:raise ValueError('Frozen file drift: '+name)
    return plan

def worker(arm,repetition,start):
    plan=verify_plan();slot=f'{arm}{repetition}';folder=ROOT/'entry_runs'/slot
    if read(folder/'claim.json')['start_monotonic']!=start:raise ValueError('Parent time origin mismatch')
    sys.path.insert(0,str(SCIENCE))
    import matlab_bridge as bridge
    from timing import MethodBudget
    from thermal import evaluate_candidate
    from schedules import validate_schedule
    budget=bind_budget(MethodBudget,start,plan['seconds'])
    bridge.REPO=folder/'isolated_preferences'
    native_return=None;initial_eval=None;final_eval=None;candidate=None;admission=None;new_admission=None;auxiliary_errors=None;transport=False
    error=None;session=None;progress=[];seen=set();evaluation_count=0
    try:
        budget.check();instance=read(ROOT/'full/input_instance.json');config=read(ROOT/'full/input_config.json')
        initial=read(ROOT/'full/initial_candidate.json');options=read(ROOT/'full/options.json')['options']
        old=payload(ROOT/'full'/(arm+'.original.mat'));new=payload(ROOT/'full'/(arm+'.mat'));cert=read(ROOT/'full'/(arm+'.certificate.json'))
        original_coordinates_unchanged(old,new,cert);budget.check()
        native_old=bridge._prepare(old,x0=old['x0']);native_new=bridge._prepare(new,x0=new['x0'])
        decoded_initial,_=decode_options(instance,options,old['x0'],1e-6,validate_schedule)
        if not same_schedule(initial,decoded_initial):raise ValueError('Initial schedule identity mismatch')
        evaluation_count+=1
        with budget.phase('initial_complete_SAFE_evaluation'):
            initial_eval=evaluate_candidate(instance,initial,config['accuracy_targets'],budget=budget)
            initial_eval['evidence_identity']=dict(input_sha256=digest(instance),candidate_sha256=digest(initial))
        save(folder/'initial_evaluation.json',initial_eval);budget.check()
        if not full_safe(initial_eval,len(instance['scenarios'])):raise ValueError('Common initial SAFE evaluation failed')
        with budget.phase('native_startup'):
            session=bridge.MatlabSession(folder/'matlab',total_budget_s=budget.remaining,budget=budget,matlab_path=plan['matlab'])
        def poll(prefix):
            for path in sorted((folder/'matlab').glob('request_000001.event_*.json')):
                if budget.remaining<=0:break
                if path.name in seen:continue
                try:event=read(path)
                except (PermissionError,json.JSONDecodeError):continue
                elapsed=budget.elapsed
                if elapsed>=plan['seconds']:break
                seen.add(path.name);record={k:v for k,v in event.items() if k!='x'};record['method_elapsed_s']=elapsed
                progress.append(record)
                with (folder/'progress.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(record,ensure_ascii=False)+'\n')
        session.event_consumer=poll
        if budget.remaining<plan['native_MaxTime']+10:raise TimeoutError('Insufficient remaining time to retain frozen native cap and validation reserve')
        native_return=session.solve(new,x0=new['x0'],budget=budget,remaining_s=budget.remaining,solver_max_time_s=plan['native_MaxTime'])
        save(folder/'native_receipt.json',native_return);budget.check()
        if not native_admissible(native_return):
            raise ValueError('Native return did not pass finite feasible-entry gate')
        with budget.phase('actual_transport_and_original_rows'):
            sent=payload(folder/'matlab/request_000001.mat');transport=array_digest(sent)==array_digest(new)
            if not transport:raise ValueError('Actual sent arrays differ from frozen transformed payload')
            _,new_admission=bridge._check_initial_point(native_new,native_return['x'])
            auxiliary_errors=complement_error(native_return['x'],cert)
            save(folder/'candidate_transformed_row_admission.json',dict(admission=new_admission,auxiliary_errors=auxiliary_errors))
            projected=inverse_vector(native_return['x'],cert)
            _,admission=bridge._check_initial_point(native_old,projected)
            candidate,legality=decode_options(instance,options,projected,1e-6,validate_schedule)
            save(folder/'candidate_original_row_admission.json',dict(admission=admission,legality=legality,candidate=candidate))
        budget.check();evaluation_count+=1
        with budget.phase('returned_candidate_complete_SAFE_evaluation'):
            final_eval=evaluate_candidate(instance,candidate,config['accuracy_targets'],budget=budget)
            final_eval['evidence_identity']=dict(input_sha256=digest(instance),candidate_sha256=digest(candidate))
        save(folder/'candidate_evaluation.json',final_eval);budget.check()
    except BaseException as exc:
        error=dict(type=type(exc).__name__,message=str(exc),traceback=traceback.format_exc())
        if hasattr(exc,'diagnostics'):error['diagnostics']=exc.diagnostics
    finally:
        stopped=budget.elapsed
        if session is not None:session.close()
    rawfile=folder/'matlab/request_000001.response.json';raw=read(rawfile) if rawfile.exists() else {}
    later,bounds=bounded_progress(progress,plan['seconds'])
    identity_ok=all(sha(name)==h for name,h in plan['frozen_files'].items())
    same=bool(candidate is not None and same_schedule(candidate,read(ROOT/'full/initial_candidate.json')))
    strict_improvement=False
    if initial_eval and final_eval and initial_eval.get('weighted_energy_J') and final_eval.get('weighted_energy_J'):
        strict_improvement=Fraction(final_eval['weighted_energy_J'][1])<Fraction(initial_eval['weighted_energy_J'][0])
    checks=dict(no_exception=error is None,initial_complete_SAFE=full_safe(initial_eval,len(read(ROOT/'full/input_instance.json')['scenarios'])),
        timely_native_return=bool(native_return and native_return.get('budget_valid') and stopped<plan['seconds']),
        native_status_and_vector_accepted=native_admissible(native_return),native_exitflag_feasible=raw.get('exitflag') in (1,2),
        original_rows_admitted=bool(admission and admission.get('accepted_numerically')),
        transformed_rows_admitted=bool(new_admission and new_admission.get('accepted_numerically')),
        returned_candidate_complete_SAFE=full_safe(final_eval,len(read(ROOT/'full/input_instance.json')['scenarios'])),
        finite_reported_lower_bound=bool(bounds),root_or_later_phase=bool(later),
        exact_expected_native_options=raw.get('options')==plan['native_options'],actual_transport_matches=transport,
        cleanup=bool(session and bridge.cleanup_is_complete(session.cleanup)),source_identity_after=identity_ok)
    receipt=dict(slot=slot,arm=arm,repetition=repetition,passed=all(checks.values()),checks=checks,error=error,
        native_calls=session.counter if session else 0,native_exitflag=raw.get('exitflag'),initial_evaluation=initial_eval,
        returned_candidate=candidate,returned_candidate_evaluation=final_eval,same_initial=same,strict_interval_energy_improvement=strict_improvement,
        original_row_admission=admission,transformed_row_admission=new_admission,auxiliary_errors=auxiliary_errors,
        initial_candidate_sha256=plan['initial_candidate_sha256'],returned_candidate_sha256=digest(candidate) if candidate else None,
        progress=progress,last_reported_bound=bounds[-1] if bounds else None,root_or_later_first=later[0] if later else None,
        method_elapsed_s=stopped,total_elapsed_s=budget.elapsed,timing=budget.summary(stopped),
        complete_candidate_evaluation_attempts=evaluation_count,maximum_candidate_evaluations=2,
        model_builds=0,feedback_rounds=0,retries=0,formal_performance_pair=False,
        scope='Native numerical entry acceptance only; native bounds not independently certified, repeated initial candidate not energy improvement. Parent-origin 300 seconds includes startup/physical validation; cleanup cannot add scientific evidence.')
    save(folder/'receipt.json',receipt)
    print(json.dumps({k:v for k,v in receipt.items() if k not in ('initial_evaluation','returned_candidate','returned_candidate_evaluation','progress','timing')},ensure_ascii=False))

def run():
    plan=verify_plan();runs=ROOT/'entry_runs';runs.mkdir(exist_ok=False);receipts=[]
    for arm,repetition in SLOTS:
        if not should_continue(receipts):break
        verify_plan();slot=f'{arm}{repetition}';folder=runs/slot;folder.mkdir();start=time.monotonic()
        save(folder/'claim.json',dict(start_monotonic=start,once_only=True,plan_sha256=sha(ROOT/'entry_plan.json')))
        temp=folder/'temp';temp.mkdir();env=dict(os.environ,TEMP=str(temp),TMP=str(temp),TMPDIR=str(temp))
        cmd=[sys.executable,'-B',str(Path(__file__).resolve()),'_worker','--arm',arm,'--repetition',str(repetition),'--start',repr(start)]
        save(folder/'command.json',dict(argv=cmd,cwd=str(ROOT),start_monotonic=start))
        with (folder/'stdout.log').open('x') as stdout,(folder/'stderr.log').open('x') as stderr:
            proc=subprocess.Popen(cmd,cwd=ROOT,env=env,stdout=stdout,stderr=stderr,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
            import psutil
            created=psutil.Process(proc.pid).create_time()
            try:code=proc.wait(timeout=max(.001,start+plan['watchdog_seconds']-time.monotonic()))
            except subprocess.TimeoutExpired:
                process=psutil.Process(proc.pid)
                if process.create_time()!=created:raise RuntimeError('Watchdog root identity changed')
                children=process.children(recursive=True)
                for child in children:child.kill()
                process.kill();gone,alive=psutil.wait_procs([process,*children],timeout=10)
                save(folder/'watchdog.json',dict(cleanup_complete=not alive,terminated_pids=[v.pid for v in gone]));code=-1
        save(folder/'controller.json',dict(returncode=code,wall_s=time.monotonic()-start))
        if code or not (folder/'receipt.json').exists():
            receipts.append(dict(slot=slot,passed=False,status='WORKER_FAILED_OR_WATCHDOG',returncode=code));break
        receipt=read(folder/'receipt.json');receipts.append(receipt)
        print((folder/'stdout.log').read_text(encoding='utf-8',errors='replace'),flush=True)
    save(runs/'summary.json',dict(passed=len(receipts)==4 and all(r['passed'] for r in receipts),receipts=receipts,
        omitted_slots=[f'{a}{n}' for a,n in SLOTS if f'{a}{n}' not in [r['slot'] for r in receipts]],
        maximum_native_calls=4,observed_native_calls=sum(r.get('native_calls',0) for r in receipts),retries=0,formal_performance_pair=False))

if __name__=='__main__':
    ap=argparse.ArgumentParser();sub=ap.add_subparsers(dest='command',required=True)
    prep=sub.add_parser('prepare');prep.add_argument('--small-receipt',type=Path,required=True);prep.add_argument('--full-receipt',type=Path,required=True)
    sub.add_parser('run');w=sub.add_parser('_worker');w.add_argument('--arm',choices=['off','on'],required=True);w.add_argument('--repetition',type=int,choices=[1,2],required=True);w.add_argument('--start',type=float,required=True)
    args=ap.parse_args()
    if args.command=='prepare':prepare(args.small_receipt,args.full_receipt)
    elif args.command=='run':run()
    else:worker(args.arm,args.repetition,args.start)
