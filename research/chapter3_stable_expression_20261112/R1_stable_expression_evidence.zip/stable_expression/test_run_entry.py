"""No native/model/physical calls: lifecycle and acceptance guard checks."""
import unittest
import numpy as np
from scipy import sparse
from complement_gate import transform
from run_entry import (SLOTS,should_continue,bind_budget,original_coordinates_unchanged,
                       decode_options,bounded_progress,full_safe,same_schedule,native_admissible,complement_error)

def payload():
    return dict(c=np.array([0.,1.]),A=sparse.csc_matrix([[4.,1.]]),b=np.array([5.]),
        Aeq=sparse.csc_matrix((0,2)),beq=np.zeros(0),lb=np.zeros(2),ub=np.array([1.,4.]),
        intcon=np.array([0],dtype=np.int64),x0=np.array([1.,1.]))

class EntryTests(unittest.TestCase):
    def test_failure_stops_all_later_slots(self):
        self.assertEqual(SLOTS,(('off',1),('on',1),('off',2),('on',2)))
        receipts=[];launched=[]
        for slot in SLOTS:
            if not should_continue(receipts):break
            launched.append(slot);receipts.append(dict(passed=slot!=('on',1)))
        self.assertEqual(launched,[('off',1),('on',1)])
    def test_no_more_than_four_even_when_every_slot_passes(self):
        receipts=[]
        while should_continue(receipts):receipts.append(dict(passed=True))
        self.assertEqual(len(receipts),4)
    def test_parent_deadline_is_not_replenished(self):
        class FakeBudget:
            def __init__(self,seconds):self.start=1000.;self.deadline=1000.+seconds
        budget=bind_budget(FakeBudget,10.,300.)
        self.assertEqual(budget.start,10.);self.assertEqual(budget.deadline,310.)
    def test_original_integer_bounds_not_fixed(self):
        p=payload();d,c=transform(p,row_gates={0:0},gate_columns=[0],mode='split_constant_v1')
        self.assertTrue(original_coordinates_unchanged(p,d,c))
        self.assertEqual(d['lb'][0],0.);self.assertEqual(d['ub'][0],1.)
        d['lb'][0]=1.
        with self.assertRaisesRegex(ValueError,'Original coordinate changed'):original_coordinates_unchanged(p,d,c)
    def test_option_projection_uses_only_original_prefix(self):
        instance={'scenarios':[{'id':'s'}]};options=[dict(scenario_id='s',stage_instance_id='s::A',unit_id='CPU1',opp_id='L',start_ms='0')]
        validate=lambda i,c:{'state':'SCHEDULE_VALID_THERMAL_UNCHECKED'}
        candidate,_=decode_options(instance,options,[1.,123.,-456.],1e-6,validate)
        self.assertEqual(candidate['scenes']['s'][0]['stage_id'],'s::A')
        with self.assertRaisesRegex(ValueError,'not a numerical binary'):decode_options(instance,options,[.5,1.,0.],1e-6,validate)
    def test_progress_and_bounds_must_precede_deadline(self):
        events=[dict(method_elapsed_s=300.,values=dict(phase='rootlp',lowerbound=.5))]
        self.assertEqual(bounded_progress(events),([],[]))
        events.append(dict(method_elapsed_s=200.,values=dict(phase='heuristics',lowerbound=.5)))
        phases,bounds=bounded_progress(events);self.assertEqual(len(phases),1);self.assertEqual(len(bounds),1)
    def test_SAFE_requires_all_scenes_and_inbudget(self):
        ev=dict(state='SAFE',rankable_energy=True,completed_at_elapsed_s=299.,scenes={'s':dict(state='SAFE',complete=True)})
        self.assertTrue(full_safe(ev,1));self.assertFalse(full_safe(ev,2))
        ev['completed_at_elapsed_s']=300.;self.assertFalse(full_safe(ev,1))
    def test_same_initial_is_semantic_not_list_order(self):
        a={'scenes':{'s':[dict(stage_id='a',unit='u',opp='L',start_ms='1/2'),dict(stage_id='b',unit='u',opp='L',start_ms='1')]}}
        b={'scenes':{'s':list(reversed(a['scenes']['s']))}}
        self.assertTrue(same_schedule(a,b))
    def test_callback_error_not_accepted_even_with_positive_exitflag(self):
        r=dict(status='SOLVED',accepted_for_evaluation=True,budget_valid=True,exitflag=2,x=[1.,1.])
        self.assertTrue(native_admissible(r))
        for key,value in [('status','CALLBACK_ERROR'),('accepted_for_evaluation',False),('budget_valid',False)]:
            changed=dict(r);changed[key]=value;self.assertFalse(native_admissible(changed))
    def test_auxiliary_error_is_recorded_exactly(self):
        p=payload();d,c=transform(p,row_gates={0:0},gate_columns=[0],mode='split_constant_v1')
        point=d['x0'].copy();point[-1]=1e-10
        errors=complement_error(point,c)
        self.assertGreater(errors['maximum_gate_complement_residual_float'],0)
        self.assertEqual(errors['maximum_fixed_offset_residual_float'],0.)

if __name__=='__main__':unittest.main(verbosity=2)
