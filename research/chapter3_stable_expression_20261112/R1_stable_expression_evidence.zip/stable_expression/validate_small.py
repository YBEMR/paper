"""Bounded complete-physics fixture gate for the complement-gate expression.

prepare freezes the protocol only. run requires that frozen plan and never
starts an optimizer. The caller must impose the declared 600 s wall watchdog.
"""
import time
ENTRY=time.monotonic()
from pathlib import Path
import argparse,hashlib,json,sys,traceback
from contextlib import ExitStack
from copy import deepcopy
from fractions import Fraction as F
from unittest.mock import patch
import numpy as np
from scipy.io import savemat

HERE=Path(__file__).resolve().parent
WORK=HERE.parent
SOURCE=WORK/'equality_pair_source'
SCIENCE=SOURCE/'research/chapter3_experiments'
sys.path.insert(0,str(SCIENCE))
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def digest(v):return hashlib.sha256(json.dumps(v,sort_keys=True,ensure_ascii=False,separators=(',',':'),default=str).encode()).hexdigest()
def save(p,v):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('x',encoding='utf-8') as f:json.dump(v,f,ensure_ascii=False,indent=2,allow_nan=False,default=str)

def fixture():
    from run_milp_precheck import select_fixture
    original=read(SOURCE/'inputs/input_instance.json');sid=original['scenarios'][0]['id']
    case,starts=select_fixture(original,'stable_expression_one_stage',{sid:['A.pre']},{'A.pre':[0,125]})
    case['start_domain']={'version':1,'kind':'explicit_grid_subset','by_scene_stage_ms':starts}
    assert case['platform']==original['platform']
    assert case['execution_rules']==original['execution_rules']
    assert case['stage_modes']['A.pre']==original['stage_modes']['A.pre']
    assert case['window_ms']==original['window_ms']
    original_scene=original['scenarios'][0]
    assert case['scenarios'][0]['entry']==original_scene['entry']
    assert case['scenarios'][0]['maximum_temperature_degC']==original_scene['maximum_temperature_degC']
    assert len(case['scenarios'])==1 and len(case['scenarios'][0]['stage_instances'])==1
    return case

def prepare(plan):
    import complement_gate
    case=fixture();config=read(SOURCE/'inputs/input_config.json')
    base=read(SOURCE/'bundle_manifest.json')['baseline_flags']
    flags={name:dict(base,propagate_support=name!='A',prune_joint_states=name=='C') for name in ['A','B','C']}
    bindings={str(p.resolve()):sha(p) for p in sorted(SOURCE.rglob('*.py'))}
    for p in [SOURCE/'inputs/input_instance.json',SOURCE/'inputs/input_config.json',Path(__file__),Path(complement_gate.__file__)]:bindings[str(p.resolve())]=sha(p)
    declaration=dict(protocol='complement-gate-one-stage-projection-and-full-physics-v1',representation_mode='split_constant_v1',
        input_fixture=case,input_config=config,flags=flags,source_sha256=bindings,
        limits=dict(wall_s=600,complete_physics_models=3,distinct_cartesian_assignments=12,group_assignment_checks=36,complete_physical_evaluations=36,native_solver_calls=0),
        fixture_scope='One original A.pre Stage; original six CPU1/CPU2 L/M/H modes and physical parameters; starts 0 and 125 ms. The latter is beyond its original deadline, so illegal assignments are included before filtering. One-scene fixture weight normalized to one only for test aggregation.',
        gates='Track actual gate arguments of unmodified Model.conditional_le and affine_conditional_eq; no coefficient-size guess. Every saved big_M row must have a tracked gate.',
        projection_scope='All declared Cartesian schedules, legal and illegal, checked using exact structural row residuals and bounds; full auxiliary-domain projection preservation follows from exact bidirectional representation certificate, not tolerance LP filtering.',
        physical_scope='For each legal schedule and each of A/B/C: complete original evaluation, complete_initial_point, forward/inverse coordinate map and decode, then a second complete evaluation. Compare all scientific receipts excluding clocks and cumulative work counters.',
        strict_mode='Try strict representable-RHS mode once per model and retain rejection; split_constant_v1 is the sole actual candidate. No alternate candidates, retries, root R1 models or native solver calls.',
        source_scope='Existing scientific files stay byte-identical; no temperature/energy accuracy change.')
    save(plan,declaration);save(str(plan)+'.identity.json',dict(sha256=sha(plan)))
    print(json.dumps(dict(plan=str(plan),sha256=sha(plan),limits=declaration['limits'])))

def scientific(v):
    excluded={'elapsed_s','completed_at_elapsed_s','formed_at_elapsed_s','panels','refinements'}
    if isinstance(v,dict):return {k:scientific(x) for k,x in v.items() if k not in excluded}
    if isinstance(v,list):return [scientific(x) for x in v]
    return v

def run(plan,out):
    out=Path(out);out.mkdir(parents=True,exist_ok=False)
    protocol=read(plan);assert sha(plan)==read(str(plan)+'.identity.json')['sha256']
    for name,h in protocol['source_sha256'].items():assert sha(name)==h,name
    import complement_gate as cg
    import milp,initial_point
    from timing import MethodBudget
    from run_milp_precheck import independent_assignments,independent_check,candidate_key,exact_row_residuals
    from test_auto_milp import structure_vector
    from schedules import validate_schedule
    from scipy import optimize
    case=protocol['input_fixture'];config=protocol['input_config'];budget=MethodBudget(600)
    budget.start=ENTRY;budget.deadline=ENTRY+600
    candidates=list(independent_assignments(case,case['start_domain']['by_scene_stage_ms']))
    assert len(candidates)==12
    expected={candidate_key(c) for c in candidates if independent_check(case,c)['valid']}
    assert len(expected)==6 and len(candidates)-len(expected)==6
    counts=dict(models=0,group_assignment_checks=0,physical_evaluations=0,native_calls=0)
    events=[];models=[];errors=[];model_gates={};model_tags={};physical_by_candidate={}
    original_init=milp.Model.__init__;original_le=milp.Model.conditional_le;original_affine=milp.Model.affine_conditional_eq
    def guarded_init(self,instance,*args,**kwargs):
        budget.check();assert counts['models']<3
        assert instance['id'].startswith('fixture_') and sum(len(s['stage_instances']) for s in instance['scenarios'])==1
        assert instance['platform']==case['platform'] and instance['stage_modes']==case['stage_modes']
        counts['models']+=1;model_gates[id(self)]={};model_tags[id(self)]={}
        return original_init(self,instance,*args,**kwargs)
    def record(self,before,gate,kind):
        for row in range(before,len(self.rows)):
            previous=model_gates[id(self)].setdefault(row,int(gate));assert previous==int(gate)
            model_tags[id(self)][row]=dict(row_zero_based=row,gate_column=int(gate),tag=self.rows[row]['tag'],captured_from=kind)
    def track_le(self,row,rhs,gate,tag):
        before=len(self.rows);value=original_le(self,row,rhs,gate,tag);record(self,before,gate,'conditional_le');return value
    def track_affine(self,target,sources,coefficients,gate,tag):
        before=len(self.rows);value=original_affine(self,target,sources,coefficients,gate,tag);record(self,before,gate,'affine_conditional_eq');return value
    def forbidden(*args,**kwargs):
        counts['native_calls']+=1;raise AssertionError('Native solver forbidden in small expression gate')
    def evaluate(model,candidate):
        budget.check();assert counts['physical_evaluations']<36
        counts['physical_evaluations']+=1
        return milp.evaluate_model_candidate(model,candidate,None,budget)
    try:
        with ExitStack() as stack:
            stack.enter_context(patch.object(milp.Model,'__init__',guarded_init))
            stack.enter_context(patch.object(milp.Model,'conditional_le',track_le))
            stack.enter_context(patch.object(milp.Model,'affine_conditional_eq',track_affine))
            stack.enter_context(patch('matlab_bridge.MatlabSession.__init__',forbidden))
            stack.enter_context(patch.object(optimize,'milp',forbidden));stack.enter_context(patch.object(optimize,'linprog',forbidden))
            for group in ['A','B','C']:
                budget.check();folder=out/group;folder.mkdir()
                model=milp.build_model(deepcopy(case),deepcopy(config),budget=budget,include_physics=True,**protocol['flags'][group])
                payload=model.as_solver_dict();payload['x0']=np.zeros(len(model.names),dtype=np.float64)
                row_gates=model_gates[id(model)];gates=sorted(set(row_gates.values()))
                assert row_gates and set(row_gates)=={i for i,row in enumerate(model.rows) if 'big_M' in row}
                save(folder/'conditional_row_gates.json',list(model_tags[id(model)].values()))
                strict={'mode':'strict','accepted':False}
                try:
                    _,strict_cert=cg.transform(payload,row_gates=row_gates,gate_columns=gates)
                    strict.update(accepted=True,certificate=strict_cert)
                except (ValueError,ArithmeticError) as error:strict.update(rejection_type=type(error).__name__,message=str(error))
                save(folder/'strict_mode_result.json',strict)
                represented,certificate=cg.transform(payload,row_gates=row_gates,gate_columns=gates,mode='split_constant_v1')
                verification=cg.verify_equivalence(payload,represented,certificate)
                save(folder/'representation_certificate.json',certificate);save(folder/'verification.json',verification)
                savemat(folder/'original_payload.mat',payload,do_compression=True,oned_as='column')
                savemat(folder/'represented_payload.mat',represented,do_compression=True,oned_as='column')
                physics_columns=set()
                for meta in model.scenes.values():
                    for field in ['theta','q']:
                        for vector in meta[field]:physics_columns.update(vector)
                    physics_columns.update(meta['energy'])
                structural=[r for r in model.rows if not (set(r['coef'])&physics_columns)]
                projected=set();assignment_records=[]
                for candidate in candidates:
                    budget.check();counts['group_assignment_checks']+=1
                    vector=np.asarray(structure_vector(model,candidate),dtype=np.float64)
                    rows=exact_row_residuals(model,vector,rows=structural)
                    bounds=all(F.from_float(float(model.lb[j]))<=F.from_float(float(vector[j]))<=F.from_float(float(model.ub[j]))
                               for j in range(len(vector)) if j not in physics_columns)
                    accepted=all(v<=0 for v in rows) and bounds
                    key=candidate_key(candidate);oracle=independent_check(case,candidate)
                    assert accepted==(key in expected)
                    assert (validate_schedule(case,candidate)['state']=='SCHEDULE_VALID_THERMAL_UNCHECKED')==oracle['valid']
                    mapped=cg.forward_vector(vector,certificate);back=cg.inverse_vector(mapped,certificate)
                    assert np.array_equal(back,vector)
                    assignment_records.append(dict(candidate=candidate,oracle_legal=oracle['valid'],oracle_reason=oracle.get('reason'),structural_rows_accept=accepted,exact_coordinate_roundtrip=True))
                    if accepted:projected.add(key)
                assert projected==expected
                save(folder/'all_cartesian_assignments.json',assignment_records)
                for ordinal,candidate in enumerate([c for c in candidates if candidate_key(c) in expected],1):
                    before=evaluate(model,candidate);assert before['state']=='SAFE' and before['rankable_energy']
                    assert all(v['complete'] and v['state']=='SAFE' for v in before['scenes'].values())
                    completed=initial_point.complete_initial_point(model,candidate,before,budget)
                    assert completed['state']=='INITIAL_POINT_READY' and completed['x0'] is not None
                    x=np.asarray(completed['x0']);z=cg.forward_vector(x,certificate);restored=cg.inverse_vector(z,certificate)
                    assert np.array_equal(x,restored)
                    decoded=milp.decode(model,restored);assert candidate_key(decoded)==candidate_key(candidate)
                    after=evaluate(model,decoded)
                    assert scientific(before)==scientific(after)
                    key=str(candidate_key(candidate));view=scientific(before)
                    if key in physical_by_candidate:assert physical_by_candidate[key]==view
                    else:physical_by_candidate[key]=view
                    save(folder/f'candidate_{ordinal:02d}.json',dict(candidate=candidate,decoded=decoded,original_evaluation=before,inverse_evaluation=after,
                        original_completion={k:v for k,v in completed.items() if k!='x0'},candidate_identity_preserved=True,
                        physical_scientific_fields_identical=True,x0_sha256=hashlib.sha256(x.tobytes()).hexdigest(),restored_x0_sha256=hashlib.sha256(restored.tobytes()).hexdigest()))
                models.append(dict(group=group,summary=model.summary(),conditional_rows=len(row_gates),gate_columns=len(gates),strict_mode_accepted=strict['accepted'],
                    exact_integer_schedule_projection_equal=True,complete_physical_candidates=6,representation=certificate))
                save(folder/'model_summary.json',model.summary())
        assert counts==dict(models=3,group_assignment_checks=36,physical_evaluations=36,native_calls=0)
        budget.check()
    except BaseException as error:errors.append(dict(type=type(error).__name__,message=str(error),traceback=traceback.format_exc()))
    unchanged=all(sha(name)==h for name,h in protocol['source_sha256'].items())
    result=dict(passed=not errors and unchanged,counts=counts,models=models,errors=errors,source_unchanged=unchanged,
        elapsed_s=time.monotonic()-ENTRY,original_full_R1_models=0,formal_pairs=0,native_solver_calls=counts['native_calls'],
        distinct_cartesian_assignments=len(candidates),legal_assignments=len(expected),illegal_assignments=len(candidates)-len(expected),
        physical_precision_unchanged=True,physical_scope='Complete original evaluator and same physical parameters; no solver-tolerance claim.',
        projection_scope='Finite declared structural schedules plus exact bidirectional certificate for full auxiliary domain; no tolerance LP screening.')
    save(out/'results.json',result)
    print(json.dumps({k:v for k,v in result.items() if k!='models'},ensure_ascii=False,indent=2))
    raise SystemExit(not result['passed'])

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('command',choices=['prepare','run']);ap.add_argument('--plan',type=Path,required=True);ap.add_argument('--out',type=Path);args=ap.parse_args()
    if args.command=='prepare':prepare(args.plan)
    else:
        assert args.out is not None
        run(args.plan,args.out)
